import AppIntents
import Foundation
import SwiftUI
import WidgetKit

private enum RuntimeBridge {
    static let controlKind = "com.yoroin.globalrefresh.control.runtime.v5"
    static let startCommand = "com.yoroin.globalrefresh.control.v4.start"
    static let stopCommand = "com.yoroin.globalrefresh.control.v4.stop"
    static let query = "com.yoroin.globalrefresh.control.v4.query"
    static let runningResponse = "com.yoroin.globalrefresh.control.v4.running"
    static let stoppedResponse = "com.yoroin.globalrefresh.control.v4.stopped"

    private final class QueryBox {
        let semaphore = DispatchSemaphore(value: 0)
        private let lock = NSLock()
        private var storedResult: Bool?

        var result: Bool? {
            lock.lock(); defer { lock.unlock() }
            return storedResult
        }

        func finish(_ value: Bool) {
            lock.lock()
            guard storedResult == nil else { lock.unlock(); return }
            storedResult = value
            lock.unlock()
            semaphore.signal()
        }
    }

    private static let queryCallback: CFNotificationCallback = { _, observer, name, _, _ in
        guard let observer, let name else { return }
        let box = Unmanaged<QueryBox>.fromOpaque(observer).takeUnretainedValue()
        switch name.rawValue as String {
        case runningResponse: box.finish(true)
        case stoppedResponse: box.finish(false)
        default: break
        }
    }

    static func liveRuntimeState(timeout: TimeInterval = 0.45) -> Bool {
        let box = QueryBox()
        let observer = Unmanaged.passUnretained(box).toOpaque()
        let center = CFNotificationCenterGetDarwinNotifyCenter()

        CFNotificationCenterAddObserver(center, observer, queryCallback, runningResponse as CFString, nil, .deliverImmediately)
        CFNotificationCenterAddObserver(center, observer, queryCallback, stoppedResponse as CFString, nil, .deliverImmediately)
        defer { CFNotificationCenterRemoveObserver(center, observer, nil, nil) }

        post(query)
        _ = box.semaphore.wait(timeout: .now() + timeout)
        return box.result ?? false
    }

    static func request(_ desired: Bool) {
        post(desired ? startCommand : stopCommand)
    }

    static func post(_ name: String) {
        CFNotificationCenterPostNotification(
            CFNotificationCenterGetDarwinNotifyCenter(),
            CFNotificationName(name as CFString),
            nil,
            nil,
            true
        )
    }
}

struct GlobalRefreshRuntimeControl: ControlWidget {
    static let kind = RuntimeBridge.controlKind

    var body: some ControlWidgetConfiguration {
        StaticControlConfiguration(kind: Self.kind, provider: Provider()) { isRunning in
            ControlWidgetToggle(
                isOn: isRunning,
                action: SetGlobalRefreshRunningIntent()
            ) {
                // Put the glyph in the primary label. Control Center renders this
                // as the native leading icon instead of treating it as value text.
                Label(
                    "GlobalRefresh X",
                    systemImage: isRunning ? "bolt.circle.fill" : "bolt.circle"
                )
            } valueLabel: { running in
                Text(running ? "运行中" : "未运行")
                    .controlWidgetStatus(running ? "运行中" : "未运行")
            }
        }
        .displayName("GlobalRefresh X")
        .description("查看并控制全局高刷。")
    }

    struct Provider: ControlValueProvider {
        var previewValue: Bool { false }

        func currentValue() async throws -> Bool {
            RuntimeBridge.liveRuntimeState()
        }
    }
}

struct SetGlobalRefreshRunningIntent: SetValueIntent {
    static let title: LocalizedStringResource = "GlobalRefresh X"
    static let description = IntentDescription("启动或停止 GlobalRefresh X 高刷核心。")
    static let supportedModes: IntentModes = [.background, .foreground(.dynamic)]

    @Parameter(title: "运行中")
    var value: Bool

    func perform() async throws -> some IntentResult {
        // First try the zero-UI fast path. If the PiP host is already executable
        // in background, the Darwin command is enough.
        RuntimeBridge.request(value)
        try? await Task.sleep(for: .milliseconds(120))

        if RuntimeBridge.liveRuntimeState(timeout: 0.18) != value,
           systemContext.currentMode.canContinueInForeground {
            // A suspended/killed UIKit host cannot be woken by a Darwin notify.
            // Bring the host scene forward only when the fast path did not work,
            // then resend after SceneDelegate had time to register its bridge.
            try await continueInForeground(IntentDialog(value ? "启动 GlobalRefresh X" : "停止 GlobalRefresh X"), alwaysConfirm: false)
            try? await Task.sleep(for: .milliseconds(320))
            RuntimeBridge.request(value)
            try? await Task.sleep(for: .milliseconds(140))
            RuntimeBridge.request(value)
        }

        try? await Task.sleep(for: .milliseconds(value ? 180 : 100))
        return .result()
    }
}

@main
struct GlobalRefreshControlBundle: WidgetBundle {
    var body: some Widget {
        GlobalRefreshRuntimeControl()
    }
}

# Alpha57 Progress

- Version: `2.0.0-alpha57`
- Build: `2026090861`
- Control kind: `com.yoroin.globalrefresh.control.runtime.v5`
- Goal: clean single-version package, native Control Center live runtime bridge, hard 120 Hz core unchanged.
- Packaging: single plain TAR source archive to avoid iOS/GitHub compound-extension corruption.
- Workflow: archive discovery is extension-tolerant and validates TAR contents before extraction.

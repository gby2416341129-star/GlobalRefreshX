# GlobalRefresh X Alpha59

- Version: 2.0.0-alpha59
- Build: 2026090863
- Control kind: com.yoroin.globalrefresh.control.runtime.v7
- Goal: i4Tools-compatible Control Center baseline.
- Removes App Group entitlements and shared UserDefaults dependency.
- Uses a stateless native ControlWidgetButton with an SF Symbol.
- Uses foreground-immediate AppIntent before sending the host toggle command.
- Keeps the PiP / 120 Hz core unchanged.
- Runtime state remains host-local; persistent Control Center running/stopped status is intentionally deferred until the signing-compatible action path is proven on device.

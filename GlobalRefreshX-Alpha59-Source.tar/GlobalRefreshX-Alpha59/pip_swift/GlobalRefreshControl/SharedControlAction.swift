import AppIntents
import Foundation

/// Alpha59 intentionally has no App Group dependency. This is designed for
/// third-party re-signing environments that rewrite application-group entitlements.
enum GlobalRefreshControlBridge {
    static let controlKind = "com.yoroin.globalrefresh.control.runtime.v7"
    static let toggleCommand = "com.yoroin.globalrefresh.control.v7.toggle"

    static func postToggleCommand() {
        CFNotificationCenterPostNotification(
            CFNotificationCenterGetDarwinNotifyCenter(),
            CFNotificationName(toggleCommand as CFString),
            nil,
            nil,
            true
        )
    }
}

/// Foreground-first action. Unlike Alpha58 this doesn't pretend a cross-process
/// shared Bool exists when the signer cannot preserve App Groups.
struct ToggleGlobalRefreshIntent: AppIntent {
    static let title: LocalizedStringResource = "GlobalRefresh X"
    static let description = IntentDescription("打开 GlobalRefresh X 并切换高刷运行状态。")
    static let supportedModes: IntentModes = [.foreground(.immediate)]

    func perform() async throws -> some IntentResult {
        GlobalRefreshControlBridge.postToggleCommand()
        return .result()
    }
}

import SwiftUI
import WidgetKit

/// Alpha59: deliberately stateless Control Center button.
/// Apple documents ControlWidgetButton for fire-and-forget actions / launching apps.
/// This avoids App Group state, which i4Tools rewrites during re-signing.
struct GlobalRefreshRuntimeControl: ControlWidget {
    static let kind = GlobalRefreshControlBridge.controlKind

    var body: some ControlWidgetConfiguration {
        StaticControlConfiguration(kind: Self.kind) {
            ControlWidgetButton(action: ToggleGlobalRefreshIntent()) {
                Label("GlobalRefresh X", systemImage: "bolt.circle.fill")
            }
        }
        .displayName("GlobalRefresh X")
        .description("打开应用并切换全局高刷。")
    }
}

@main
struct GlobalRefreshControlBundle: WidgetBundle {
    var body: some Widget {
        GlobalRefreshRuntimeControl()
    }
}

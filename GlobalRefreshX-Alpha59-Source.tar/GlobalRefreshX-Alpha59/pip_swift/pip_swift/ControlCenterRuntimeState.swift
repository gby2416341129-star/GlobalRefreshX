import Foundation
import WidgetKit

/// Host-only runtime truth. Alpha59 no longer exports this through App Groups.
enum ControlCenterRuntimeState {
    static let controlKind = GlobalRefreshControlBridge.controlKind
    static let toggleCommandNotification = GlobalRefreshControlBridge.toggleCommand

    private static let stateQueue = DispatchQueue(label: "com.yoroin.globalrefresh.control-runtime-state")
    private static var runtimeRunning = false

    static var isRuntimeRunning: Bool { stateQueue.sync { runtimeRunning } }
    static func markRunning() { stateQueue.sync { runtimeRunning = true } }
    static func markStopped() { stateQueue.sync { runtimeRunning = false } }
}

#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
pass=0
check() { if eval "$2"; then echo "PASS: $1"; pass=$((pass + 1)); else echo "FAIL: $1" >&2; exit 1; fi; }

PROJECT="pip_swift/pip_swift.xcodeproj/project.pbxproj"
APP="pip_swift/pip_swift"

check 'Speed version' "grep -q 'MARKETING_VERSION = 2.1.0' '$PROJECT'"
check 'Speed build number' "grep -q 'CURRENT_PROJECT_VERSION = 2026090865' '$PROJECT'"
check 'Speed bundle identifier' "grep -q 'PRODUCT_BUNDLE_IDENTIFIER = com.isil.speed' '$PROJECT'"
check 'Speed product name' "grep -q 'PRODUCT_NAME = Speed' '$PROJECT'"
check 'Automatic signing ready' "grep -q 'CODE_SIGN_STYLE = Automatic' '$PROJECT'"
check 'App display name' "grep -A1 '<key>CFBundleDisplayName</key>' '$APP/Info.plist' | grep -q '<string>Speed</string>'"
check 'No extension target' "! grep -q 'PBXNativeTarget.*Control\|Embed App Extensions\|GlobalRefreshControl' '$PROJECT'"
check 'No old pages' "test -z \"\$(find '$APP' \\( -name '*FrameRateTest*' -o -name 'VersionViewController.swift' -o -name 'TutorialTabBarController.swift' \\) -print)\""
check 'No shortcut bridge' "! grep -R -q -i 'PiPShortcut\|ControlCenterRuntimeState\|shortcutStartRetry' '$APP' --include='*.swift'"
check 'No network polling' "! grep -R -q -i 'NetworkTrafficSample\|URLSession' '$APP' --include='*.swift' && ! grep -q 'import Darwin' '$APP/ViewController.swift'"
check 'Single main screen' "! grep -q 'UITabBarController' '$APP/MainTabBarController.swift'"
check '120Hz minimum pin retained' "grep -R -q 'minimum: requested' '$APP' --include='*.swift'"
check '120Hz maximum pin retained' "grep -R -q 'maximum: requested' '$APP' --include='*.swift'"
check '120Hz preferred pin retained' "grep -R -q 'preferred: requested' '$APP' --include='*.swift'"
check 'Minimum frame duration plist retained' "grep -q 'CADisableMinimumFrameDurationOnPhone' '$APP/Info.plist'"
check 'No legacy product identity' "! grep -R -q -i 'globalrefresh\|yoroin\|caiwanfeng' --exclude=NOTICE --exclude=verify_project.sh --exclude-dir=Pods --exclude-dir=.git ."

echo "Verification passed: $pass/$pass"

import SwiftUI
import UIKit

/// Speed's single-screen control surface. It intentionally contains no live
/// frame sampler, network reader, update checker, or continuously animated view.
struct PiPHomeView: View {
    @Binding var isPiPActive: Bool

    let presentationState: HomePresentationState
    let pipHeight: String
    let pipRunningDuration: String
    let isCurrentAppearanceDark: Bool
    let pipEngineRoute: PiPEngineRoute
    let isSettingsExpanded: Bool
    let onTogglePiP: () -> Void
    let onStartAndHidePiP: () -> Void
    let onToggleStyle: () -> Void
    let onCustomizeHeight: () -> Void
    let onToggleAppearanceMode: () -> Void
    let onToggleSettings: () -> Void
    let onDismissSettings: () -> Void
    let onSetPiPEngineRoute: (PiPEngineRoute) -> Void

    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        ZStack {
            SpeedBackground()
                .ignoresSafeArea()
                .contentShape(Rectangle())
                .onTapGesture(perform: onDismissSettings)

            GeometryReader { proxy in
                ScrollView(showsIndicators: false) {
                    VStack(spacing: proxy.size.height < 700 ? 15 : 20) {
                        header
                        statusCard
                        controls
                        if isSettingsExpanded {
                            settingsCard
                                .transition(
                                    reduceMotion
                                        ? .opacity
                                        : .opacity.combined(with: .scale(scale: 0.97, anchor: .top))
                                )
                        }
                        Spacer(minLength: 8)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, max(proxy.safeAreaInsets.top + 10, 18))
                    .padding(.bottom, max(proxy.safeAreaInsets.bottom + 18, 26))
                    .frame(minHeight: proxy.size.height, alignment: .top)
                }
                .scrollBounceBehavior(.basedOnSize)
            }
        }
        .animation(reduceMotion ? nil : .snappy(duration: 0.24), value: isSettingsExpanded)
    }

    private var header: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 3) {
                Text("Speed")
                    .font(.system(size: 34, weight: .bold, design: .rounded))
                    .tracking(-1.1)
                Text(L10n.text("让每一次滑动都更跟手", "Smoother motion, instantly"))
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(.secondary)
            }

            Spacer(minLength: 8)

            iconButton(
                systemName: isCurrentAppearanceDark ? "sun.max.fill" : "moon.fill",
                accessibilityLabel: L10n.text("切换外观", "Change appearance"),
                action: onToggleAppearanceMode
            )

            iconButton(
                systemName: isSettingsExpanded ? "xmark" : "slider.horizontal.3",
                accessibilityLabel: L10n.text("设置", "Settings"),
                action: onToggleSettings
            )
        }
    }

    private var statusCard: some View {
        SpeedGlassCard {
            VStack(alignment: .leading, spacing: 18) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 0) {
                        HStack(alignment: .firstTextBaseline, spacing: 6) {
                            Text("\(presentationState.requestedFrameRate)")
                                .font(.system(size: 58, weight: .semibold, design: .rounded))
                                .monospacedDigit()
                                .contentTransition(reduceMotion ? .identity : .numericText())
                            Text("Hz")
                                .font(.title3.weight(.semibold))
                                .foregroundStyle(.secondary)
                        }
                        Text(L10n.text("目标刷新率", "Target refresh rate"))
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.tertiary)
                    }

                    Spacer(minLength: 12)

                    Image(systemName: presentationState.statusSystemImage)
                        .font(.system(size: 24, weight: .semibold))
                        .foregroundStyle(isPiPActive ? Color.cyan : Color.secondary)
                        .frame(width: 50, height: 50)
                        .background(.thinMaterial, in: Circle())
                }

                HStack(spacing: 10) {
                    Circle()
                        .fill(isPiPActive ? Color.green : Color.secondary.opacity(0.55))
                        .frame(width: 8, height: 8)
                    Text(localizedStatusTitle)
                        .font(.headline)
                    Spacer()
                    if isPiPActive {
                        Text(pipRunningDuration)
                            .font(.subheadline.monospacedDigit().weight(.medium))
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(localizedStatusTitle), \(presentationState.requestedFrameRate) Hz")
    }

    private var controls: some View {
        VStack(spacing: 12) {
            Button(action: withHaptic(onTogglePiP)) {
                HStack(spacing: 10) {
                    Image(systemName: presentationState.primaryActionSystemImage)
                    Text(primaryActionTitle)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.subheadline.weight(.bold))
                        .opacity(0.68)
                }
                .font(.headline)
                .foregroundStyle(.white)
                .padding(.horizontal, 18)
                .frame(maxWidth: .infinity, minHeight: 58)
                .background(primaryGradient, in: RoundedRectangle(cornerRadius: 19, style: .continuous))
                .shadow(color: Color.blue.opacity(isPiPActive ? 0.12 : 0.28), radius: 16, y: 8)
            }
            .buttonStyle(SpeedPressButtonStyle())
            .disabled(!presentationState.allowsPrimaryAction)
            .opacity(presentationState.allowsPrimaryAction ? 1 : 0.62)

            Button(action: withHaptic(onStartAndHidePiP)) {
                HStack(spacing: 9) {
                    Image(systemName: "eye.slash.fill")
                    Text(L10n.text("吸附后隐藏到 \(minimumHeightText)", "Hide to \(minimumHeightText) after docking"))
                }
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)
                .frame(maxWidth: .infinity, minHeight: 48)
                .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 17, style: .continuous)
                        .stroke(.primary.opacity(0.07), lineWidth: 0.5)
                }
            }
            .buttonStyle(SpeedPressButtonStyle())
            .disabled(!presentationState.allowsHideAction)
        }
    }

    private var settingsCard: some View {
        SpeedGlassCard {
            VStack(spacing: 0) {
                settingButton(
                    title: L10n.text("悬浮窗样式", "Floating style"),
                    value: L10n.text("轻点切换", "Tap to change"),
                    systemName: "rectangle.compress.vertical",
                    action: onToggleStyle
                )
                divider
                settingButton(
                    title: L10n.text("悬浮窗高度", "PiP height"),
                    value: pipHeight,
                    systemName: "arrow.up.and.down",
                    action: onCustomizeHeight
                )
                divider
                enginePicker
            }
        }
    }

    private var enginePicker: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label(L10n.text("运行模式", "Engine mode"), systemImage: "cpu")
                .font(.subheadline.weight(.semibold))

            HStack(spacing: 8) {
                engineButton(
                    title: L10n.text("标准", "Standard"),
                    route: .videoCall
                )
                engineButton(
                    title: L10n.text("兼容", "Compatible"),
                    route: .playerLayerGenerated
                )
            }
        }
        .padding(.vertical, 15)
    }

    private func engineButton(title: String, route: PiPEngineRoute) -> some View {
        let selected = pipEngineRoute.usesPlayerLayer == route.usesPlayerLayer
        return Button(action: withHaptic { onSetPiPEngineRoute(route) }) {
            Text(title)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(selected ? Color.white : Color.primary)
                .frame(maxWidth: .infinity, minHeight: 38)
                .background(
                    selected ? Color.blue : Color.primary.opacity(0.055),
                    in: RoundedRectangle(cornerRadius: 12, style: .continuous)
                )
        }
        .buttonStyle(SpeedPressButtonStyle())
    }

    private func settingButton(
        title: String,
        value: String,
        systemName: String,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: withHaptic(action)) {
            HStack(spacing: 13) {
                Image(systemName: systemName)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(Color.blue)
                    .frame(width: 34, height: 34)
                    .background(Color.blue.opacity(0.11), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                Text(title)
                    .font(.body.weight(.medium))
                    .foregroundStyle(.primary)
                Spacer()
                Text(value)
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(.secondary)
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.tertiary)
            }
            .frame(minHeight: 56)
        }
        .buttonStyle(.plain)
    }

    private func iconButton(
        systemName: String,
        accessibilityLabel: String,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: withHaptic(action)) {
            Image(systemName: systemName)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.primary)
                .frame(width: 44, height: 44)
                .background(.thinMaterial, in: Circle())
                .overlay { Circle().stroke(.primary.opacity(0.07), lineWidth: 0.5) }
        }
        .buttonStyle(SpeedPressButtonStyle())
        .accessibilityLabel(accessibilityLabel)
    }

    private var divider: some View {
        Divider().padding(.leading, 47)
    }

    private var primaryGradient: LinearGradient {
        LinearGradient(
            colors: isPiPActive
                ? [Color(red: 0.24, green: 0.27, blue: 0.34), Color(red: 0.13, green: 0.15, blue: 0.20)]
                : [Color(red: 0.07, green: 0.62, blue: 1.0), Color(red: 0.20, green: 0.34, blue: 1.0)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }

    private var localizedStatusTitle: String {
        switch presentationState.activity {
        case .ready: return L10n.text("已就绪", "Ready")
        case .starting: return L10n.text("正在启动", "Starting")
        case .running: return L10n.text("高刷运行中", "High refresh active")
        case .hidden: return L10n.text("高刷运行中 · 已隐藏", "High refresh active · Hidden")
        case .stopping: return L10n.text("正在关闭", "Stopping")
        case .failed: return L10n.text("需要重新尝试", "Try again")
        }
    }

    private var primaryActionTitle: String {
        isPiPActive
            ? L10n.text("关闭 Speed", "Stop Speed")
            : L10n.text("开启 Speed", "Start Speed")
    }

    private var minimumHeightText: String {
        pipEngineRoute.usesPlayerLayer ? "1 pt" : "0.1 pt"
    }

    private func withHaptic(_ action: @escaping () -> Void) -> () -> Void {
        {
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
            action()
        }
    }
}

private struct SpeedBackground: View {
    var body: some View {
        ZStack {
            Color(UIColor.systemGroupedBackground)
            LinearGradient(
                colors: [Color.blue.opacity(0.12), Color.cyan.opacity(0.045), .clear],
                startPoint: .topLeading,
                endPoint: .center
            )
        }
    }
}

private struct SpeedGlassCard<Content: View>: View {
    private let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        content
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(cardBackground)
    }

    @ViewBuilder
    private var cardBackground: some View {
        let shape = RoundedRectangle(cornerRadius: 24, style: .continuous)
        if #available(iOS 26.0, *) {
            shape
                .fill(Color(UIColor.secondarySystemGroupedBackground).opacity(0.22))
                .glassEffect(.regular.interactive(), in: shape)
                .overlay { shape.stroke(.primary.opacity(0.075), lineWidth: 0.5) }
        } else {
            shape
                .fill(.regularMaterial)
                .overlay { shape.stroke(.primary.opacity(0.075), lineWidth: 0.5) }
        }
    }
}

private struct SpeedPressButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.985 : 1)
            .opacity(configuration.isPressed ? 0.88 : 1)
            .animation(.easeOut(duration: 0.12), value: configuration.isPressed)
    }
}

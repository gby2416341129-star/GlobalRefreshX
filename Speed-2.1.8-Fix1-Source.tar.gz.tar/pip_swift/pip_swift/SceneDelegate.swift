import UIKit

final class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?

    func scene(
        _ scene: UIScene,
        willConnectTo session: UISceneSession,
        options connectionOptions: UIScene.ConnectionOptions
    ) {
        guard let windowScene = scene as? UIWindowScene else { return }

        let window = UIWindow(windowScene: windowScene)
        window.rootViewController = ViewController()
        AppAppearancePreference.apply(to: window)
        self.window = window
        window.makeKeyAndVisible()

        RefreshRateController.shared.reconcile()
    }

    func sceneDidBecomeActive(_ scene: UIScene) {
        RefreshRateController.shared.reconcile()
#if DEBUG
        DebugDiagnosticsMonitor.startIfNeeded()
#endif
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
#if DEBUG
        DebugDiagnosticsMonitor.stop()
#endif
        RefreshRateController.shared.reconcile()
    }

    func sceneDidDisconnect(_ scene: UIScene) {
        RefreshRateController.shared.stop()
    }

    deinit {
        RefreshRateController.shared.stop()
    }
}

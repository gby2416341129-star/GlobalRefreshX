import UIKit

/// Speed has no frame-rate laboratory UI. The production policy is fixed:
/// request the display's supported maximum and keep it out of user defaults.
enum FrameRatePreference {
    static let didChangeNotification = Notification.Name("speed.refreshRatePolicyDidChange")
    static var isHighRefreshEnabled: Bool { true }
    static var targetFrameRate: Int { min(120, AppDisplayContext.maximumFramesPerSecond) }

    static func preferredFrameRateValue(target: Float) -> Float { target }
}

/// Current runtime route. Persistence is deliberately excluded: UserDefaults remembers the
/// next-launch choice but can never decide whether the live refresh driver is running.
enum RefreshRuntimeMode: Equatable {
    case videoCall
    case playerLayer
}

enum AppDisplayContext {
    static var activeWindowScene: UIWindowScene? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        return scenes.first(where: { $0.activationState == .foregroundActive })
            ?? scenes.first(where: { $0.activationState == .foregroundInactive })
            ?? scenes.first
    }

    static var screen: UIScreen? { activeWindowScene?.screen }
    static var bounds: CGRect { screen?.bounds ?? .zero }
    static var scale: CGFloat { max(screen?.scale ?? 1, 1) }
    static var maximumFramesPerSecond: Int { max(screen?.maximumFramesPerSecond ?? 60, 60) }
}

/// Owns the one and only persistent hard-maximum refresh request.
/// Hot path: one CADisplayLink, .common run loop, empty callback.
final class RefreshRateController {
    static let shared = RefreshRateController()

    private var displayLink: CADisplayLink?
    private var configuredFrameRate: Float = 0
    private(set) var runtimeMode: RefreshRuntimeMode = .videoCall

    private init() {}

    var isRunning: Bool { displayLink != nil }

    func setRuntimeMode(_ mode: RefreshRuntimeMode) {
        guard runtimeMode != mode else { return }
        runtimeMode = mode
        reconcile()
    }

    func reconcile() {
        // PlayerLayer keeps its own known-compatible media cadence. The hard-max app-level
        // request belongs only to the VideoCall route so two persistent cadence sources never
        // compete on the main run loop.
        guard FrameRatePreference.isHighRefreshEnabled, runtimeMode == .videoCall else {
            stop()
            return
        }
        startOrUpdate()
    }

    func stop() {
        displayLink?.invalidate()
        displayLink = nil
        configuredFrameRate = 0
    }

    private func startOrUpdate() {
        let requested = requestedFrameRate()
        if let displayLink {
            if configuredFrameRate != requested {
                configure(displayLink, requested: requested)
            }
            if displayLink.isPaused { displayLink.isPaused = false }
            return
        }

        let link = CADisplayLink(target: self, selector: #selector(step(_:)))
        configure(link, requested: requested)
        link.add(to: .main, forMode: .common)
        link.isPaused = false
        displayLink = link
    }

    private func requestedFrameRate() -> Float {
        Float(min(FrameRatePreference.targetFrameRate, AppDisplayContext.maximumFramesPerSecond))
    }

    private func configure(_ link: CADisplayLink, requested: Float) {
        link.preferredFrameRateRange = CAFrameRateRange(
            minimum: requested,
            maximum: requested,
            preferred: requested
        )
        configuredFrameRate = requested
    }

    @objc private func step(_ link: CADisplayLink) {
        // Intentionally empty. Any work here steals from the 8.33 ms frame budget.
    }
}

#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP_DIR="$ROOT/pip_swift/pip_swift"
PBX="$ROOT/pip_swift/pip_swift.xcodeproj/project.pbxproj"
PLIST="$APP_DIR/Info.plist"

echo "[1/35] Validate Info.plist"
plutil -lint "$PLIST" >/dev/null

echo "[2/35] Enforce iOS 26+ / iPhone-only policy"
if grep -Eq 'IPHONEOS_DEPLOYMENT_TARGET = (1[0-9]|2[0-5])\.' "$PBX"; then
  echo "ERROR: deployment target below iOS 26 found" >&2; exit 1
fi
if grep -Eq 'TARGETED_DEVICE_FAMILY = "?[^1;]' "$PBX"; then
  echo "ERROR: non-iPhone target family found" >&2; exit 1
fi

echo "[3/35] Reject stale armv7 requirement"
if grep -Rqs '<string>armv7</string>' "$APP_DIR"; then
  echo "ERROR: stale armv7 capability found" >&2; exit 1
fi

echo "[4/35] Check Swift syntax"
if command -v swiftc >/dev/null 2>&1; then
  while IFS= read -r -d '' file; do
    swiftc -frontend -parse "$file" >/dev/null
  done < <(find "$APP_DIR" -name '*.swift' -print0)
else
  echo "WARN: swiftc unavailable; syntax parse deferred to Xcode CI"
fi

echo "[5/35] Check project references for GlobalRefresh X core files"
for name in RefreshRateController.swift PiPGeometryController.swift PiPLifecycleController.swift PiPEngineController.swift PiPTransitionCoordinator.swift PiPCompatibilityAdapter.swift PiPTaskScheduler.swift AppDesignSystem.swift AppMotion.swift HomePresentationState.swift DelayedTaskScheduler.swift; do
  grep -q "$name" "$PBX" || { echo "ERROR: $name missing from Xcode project" >&2; exit 1; }
done

echo "[6/35] Detect merge-conflict markers"
if grep -RInE '^(<<<<<<<|=======|>>>>>>>)' "$APP_DIR" --include='*.swift' --include='*.plist'; then
  echo "ERROR: merge conflict markers found" >&2; exit 1
fi

echo "[7/35] Enforce animation ownership"
if grep -RIn 'UIView\.animate[[:space:]]*(' "$APP_DIR" --include='*.swift'; then
  echo "ERROR: unmanaged UIView.animate call found; use AppMotion/UIViewPropertyAnimator" >&2; exit 1
fi

echo "[8/35] Enforce PiP async-task ownership"
if grep -n 'DispatchWorkItem' "$APP_DIR/ViewController.swift"; then
  echo "ERROR: ViewController owns raw DispatchWorkItem; use PiPTaskScheduler" >&2; exit 1
fi

echo "[9/35] Enforce opt-in diagnostics runtime"
if ! grep -q 'guard AppDebugLogger.isDebugModeEnabled else' "$APP_DIR/AppDebugLogger.swift"; then
  echo "ERROR: debug diagnostics master gate missing" >&2; exit 1
fi

echo "[10/35] Enforce tab shortcut async-task ownership"
if grep -n 'DispatchWorkItem' "$APP_DIR/MainTabBarController.swift"; then
  echo "ERROR: MainTabBarController owns raw DispatchWorkItem; use DelayedTaskScheduler" >&2; exit 1
fi

echo "[11/35] Enforce keep-alive delayed-task ownership"
if grep -n 'DispatchWorkItem' "$APP_DIR/KeepAliveLogger.swift"; then
  echo "ERROR: KeepAliveLogger owns raw DispatchWorkItem; use DelayedTaskScheduler" >&2; exit 1
fi

echo "[12/35] Reject animated SwiftUI blur on primary home surface"
if grep -nE '\.blur\(radius:[^)]*\?' "$APP_DIR/PiPViews.swift"; then
  echo "ERROR: state-driven blur animation found on PiPViews; prefer opacity/transform for 120 Hz paths" >&2; exit 1
fi

echo "[13/35] Reject redundant FPS probe DisplayLink in PiP runtime"
if grep -nE 'fpsProbeDisplayLink|updateFPSProbe' "$APP_DIR/ViewController.swift"; then
  echo "ERROR: redundant FPS probe DisplayLink reintroduced; keep release-critical PiP runtime lean" >&2; exit 1
fi

echo "[14/35] Enforce lazy debug-log message construction"
if ! grep -q 'static func log(_ message: @autoclosure' "$APP_DIR/AppDebugLogger.swift"; then
  echo "ERROR: debug log messages are eager; release 120 Hz paths must not build disabled diagnostics strings" >&2; exit 1
fi

echo "[15/35] Reject unreachable pre-iOS-26 compatibility branches"
if grep -RIn '#unavailable(iOS 26' "$APP_DIR" --include='*.swift'; then
  echo "ERROR: pre-iOS-26 compatibility branch found in an iOS-26+ app" >&2; exit 1
fi

echo "[16/35] Enforce foreground-only UI runtime ticker"
if ! grep -A8 'private func startPiPRuntimeTimerIfNeeded()' "$APP_DIR/ViewController.swift" | grep -q 'applicationState == .active'; then
  echo "ERROR: PiP runtime UI ticker can run outside foreground" >&2; exit 1
fi

echo "[17/35] Enforce zero-cost disabled background clock diagnostics"
if ! grep -A8 'private func logBackgroundClockDiagnosticsIfNeeded' "$APP_DIR/ViewController.swift" | grep -q 'guard AppDebugLogger.isDebugModeEnabled else'; then
  echo "ERROR: display-link background diagnostics lack an immediate debug-mode gate" >&2; exit 1
fi

echo "[18/35] Reject duplicate measured-FPS reset regression"
python3 - "$APP_DIR/ViewController.swift" <<'PYVERIFY'
import sys
from pathlib import Path
text = Path(sys.argv[1]).read_text()
needle = "measuredPiPFPS = 0\n        measuredPiPFPS = 0"
if needle in text:
    raise SystemExit("ERROR: duplicate measuredPiPFPS reset found")
PYVERIFY

echo "[19/35] Enforce CocoaPods iOS 26 deployment target"
if ! grep -q "platform :ios, '26.0'" "$ROOT/pip_swift/podfile"; then
  echo "ERROR: Podfile deployment target must match iOS 26 app policy" >&2; exit 1
fi

echo "[20/35] Enforce build-time verification gate"
if ! grep -q '"$ROOT/scripts/verify_project.sh"' "$ROOT/scripts/build_unsigned_ipa.sh"; then
  echo "ERROR: unsigned IPA build must run project verification first" >&2; exit 1
fi

echo "[21/35] Reject stale MainTabBarController compile blockers"
if grep -nE 'pendingShortcutRetryWorkItems|refreshDisplayLink' "$APP_DIR/MainTabBarController.swift"; then
  echo "ERROR: stale removed MainTabBarController symbols reintroduced" >&2; exit 1
fi

echo "[22/35] Enforce cancellable delayed tab UI work"
if grep -n 'DispatchQueue\.main\.asyncAfter' "$APP_DIR/MainTabBarController.swift"; then
  echo "ERROR: MainTabBarController delayed UI work must use DelayedTaskScheduler" >&2; exit 1
fi

echo "[23/35] Enforce disabled high-refresh driver release"
if ! grep -q 'guard FrameRatePreference.isHighRefreshEnabled, !playerLayer, !extremeSilent else' "$ROOT/pip_swift/pip_swift/RefreshRateController.swift"; then
  echo "RefreshRateController must fully stop its app-level display link when high refresh is disabled." >&2
  exit 1
fi

echo "[24/35] Enforce modern iOS 26 frame-rate API"
if grep -RIn 'preferredFramesPerSecond' "$APP_DIR" --include='*.swift'; then
  echo "ERROR: deprecated preferredFramesPerSecond found; iOS 26+ target must use preferredFrameRateRange" >&2; exit 1
fi

echo "[25/35] Enforce stale PiP retry generation guards"
if ! grep -q 'directCloseGestureRetryGeneration == generation' "$APP_DIR/ViewController.swift" || ! grep -q 'legacyCustomViewAttachRetryGeneration == generation' "$APP_DIR/ViewController.swift"; then
  echo "ERROR: delayed PiP retry batches must reject callbacks from superseded generations" >&2; exit 1
fi

echo "[26/35] Enforce foreground-resign retry generation guard"
if ! grep -q 'foregroundResignRetryGeneration == generation' "$APP_DIR/ViewController.swift"; then
  echo "ERROR: foreground-resign retry batch must reject callbacks from superseded generations" >&2; exit 1
fi

echo "[27/35] Enforce iPhoneOS 26+ SDK build preflight"
if ! grep -q 'xcrun --sdk iphoneos --show-sdk-version' "$ROOT/scripts/build_unsigned_ipa.sh" || ! grep -q 'major < 26' "$ROOT/scripts/build_unsigned_ipa.sh"; then
  echo "ERROR: unsigned IPA build must reject Xcode installations without the iPhoneOS 26+ SDK" >&2; exit 1
fi


echo "[28/35] Verify Xcode Swift source membership matches disk"
python3 - "$APP_DIR" "$PBX" <<'PYVERIFY'
import re
import sys
from pathlib import Path

app_dir = Path(sys.argv[1])
pbx = Path(sys.argv[2]).read_text(errors="ignore")

disk = {p.name for p in app_dir.rglob("*.swift")}
project = set(re.findall(r"/\* ([^*]+\.swift) \*/ = \{isa = PBXFileReference;", pbx))

missing_from_project = sorted(disk - project)
missing_from_disk = sorted(project - disk)
if missing_from_project:
    raise SystemExit("ERROR: Swift files exist on disk but are not referenced by Xcode: " + ", ".join(missing_from_project))
if missing_from_disk:
    raise SystemExit("ERROR: Xcode references Swift files missing on disk: " + ", ".join(missing_from_disk))
PYVERIFY

echo "[29/35] Enforce CI Xcode 26+ selector"
if ! grep -q 'runs-on: macos-26' "$ROOT/.github/workflows/build-ipa.yml" || ! grep -q './scripts/select_xcode_26.sh' "$ROOT/.github/workflows/build-ipa.yml"; then
  echo "ERROR: GitHub Actions must use macOS 26 and the Xcode 26+ selector." >&2; exit 1
fi
if grep -q '/Applications/Xcode.app/Contents/Developer' "$ROOT/.github/workflows/build-ipa.yml"; then
  echo "ERROR: hard-coded default Xcode path reintroduced." >&2; exit 1
fi


echo "[30/35] Enforce persistent Xcode failure diagnostics"
if ! grep -q -- '-resultBundlePath "$RESULT_BUNDLE"' "$ROOT/scripts/build_unsigned_ipa.sh" || ! grep -q 'tee "$BUILD_LOG"' "$ROOT/scripts/build_unsigned_ipa.sh"; then
  echo "ERROR: unsigned IPA build must preserve xcodebuild log and xcresult diagnostics." >&2; exit 1
fi
if ! grep -q 'name: Upload Xcode diagnostics' "$ROOT/.github/workflows/build-ipa.yml" || ! grep -q 'if: always()' "$ROOT/.github/workflows/build-ipa.yml"; then
  echo "ERROR: CI must upload Xcode diagnostics even when the build fails." >&2; exit 1
fi


echo "[31/35] Enforce iPhone-only app icon catalog"
python3 - "$APP_DIR/Assets.xcassets/AppIcon.appiconset/Contents.json" "$PBX" <<'PYVERIFY'
import json
import sys
from pathlib import Path

contents = Path(sys.argv[1])
pbx = Path(sys.argv[2]).read_text(errors="ignore")
data = json.loads(contents.read_text())
images = data.get("images", [])
if any(item.get("idiom") == "ipad" for item in images):
    raise SystemExit("ERROR: iPad app icon declarations remain in iPhone-only target")
if "ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon;" not in pbx:
    raise SystemExit("ERROR: primary AppIcon build setting is missing")
required = {("iphone", "60x60", "2x"), ("iphone", "60x60", "3x"), ("ios-marketing", "1024x1024", "1x")}
present = {(i.get("idiom"), i.get("size"), i.get("scale")) for i in images}
missing = sorted(required - present)
if missing:
    raise SystemExit("ERROR: required iPhone app icon slots missing: " + repr(missing))
for item in images:
    filename = item.get("filename")
    if filename and not (contents.parent / filename).is_file():
        raise SystemExit("ERROR: app icon file missing: " + filename)
PYVERIFY


echo "[32/35] Reject duplicate PBX object identifiers"
python3 - "$PBX" <<'PYVERIFY'
import re
import sys
from collections import Counter
from pathlib import Path
text = Path(sys.argv[1]).read_text(errors="ignore")
# Object definitions are lines whose identifier precedes a comment and '= {'.
ids = re.findall(r'^\s*([A-Za-z0-9]+)\s+/\*.*?\*/\s*=\s*\{', text, flags=re.M)
duplicates = sorted(k for k, v in Counter(ids).items() if v > 1)
if duplicates:
    raise SystemExit("ERROR: duplicate PBX object identifiers: " + ", ".join(duplicates))
PYVERIFY


echo "[33/35] Verify PBX build-phase graph integrity"
python3 - "$PBX" <<'PYVERIFY'
import re
import sys
from pathlib import Path

text = Path(sys.argv[1]).read_text(errors="ignore")

def section(name):
    m = re.search(rf'/\* Begin {re.escape(name)} section \*/(.*?)/\* End {re.escape(name)} section \*/', text, re.S)
    if not m:
        raise SystemExit(f"ERROR: missing {name} section")
    return m.group(1)

# Parse build-file -> file-reference edges.
build_files = {}
for m in re.finditer(
    r'^\s*([A-Za-z0-9]+)\s+/\* (.*?) \*/\s*=\s*\{isa = PBXBuildFile;\s*fileRef = ([A-Za-z0-9]+)\s+/\* (.*?) \*/;\s*\};',
    section('PBXBuildFile'),
    re.M,
):
    build_files[m.group(1)] = (m.group(3), m.group(2), m.group(4))

file_refs = {
    m.group(1): m.group(2)
    for m in re.finditer(
        r'^\s*([A-Za-z0-9]+)\s+/\* (.*?) \*/\s*=\s*\{isa = PBXFileReference;',
        section('PBXFileReference'),
        re.M,
    )
}
variant_groups = {
    m.group(1): m.group(2)
    for m in re.finditer(
        r'^\s*([A-Za-z0-9]+)\s+/\* (.*?) \*/\s*=\s*\{\s*isa = PBXVariantGroup;',
        section('PBXVariantGroup'),
        re.M,
    )
}
valid_file_nodes = set(file_refs) | set(variant_groups)

bad_edges = sorted(
    (bid, file_ref, label)
    for bid, (file_ref, label, _file_label) in build_files.items()
    if file_ref not in valid_file_nodes
)
if bad_edges:
    raise SystemExit('ERROR: PBXBuildFile references missing file nodes: ' + repr(bad_edges))

phase_kinds = {
    'PBXSourcesBuildPhase': 'Sources',
    'PBXResourcesBuildPhase': 'Resources',
    'PBXFrameworksBuildPhase': 'Frameworks',
}
phase_members = {}
for sec_name, friendly in phase_kinds.items():
    sec = section(sec_name)
    ids = re.findall(r'\b([A-Za-z0-9]+)\s+/\*.*?\*/\s*,', sec)
    phase_members[friendly] = ids
    undefined = sorted(set(ids) - set(build_files))
    if undefined:
        raise SystemExit(f'ERROR: {friendly} phase references undefined PBXBuildFile ids: ' + ', '.join(undefined))
    duplicates = sorted({x for x in ids if ids.count(x) > 1})
    if duplicates:
        raise SystemExit(f'ERROR: duplicate PBXBuildFile ids inside {friendly} phase: ' + ', '.join(duplicates))

all_phase_ids = [x for ids in phase_members.values() for x in ids]
orphan_build_files = sorted(set(build_files) - set(all_phase_ids))
if orphan_build_files:
    raise SystemExit('ERROR: PBXBuildFile objects are not owned by Sources/Resources/Frameworks: ' + ', '.join(orphan_build_files))

cross_phase = sorted({x for x in all_phase_ids if all_phase_ids.count(x) > 1})
if cross_phase:
    raise SystemExit('ERROR: PBXBuildFile appears in multiple build phases: ' + ', '.join(cross_phase))

# Type/phase consistency: every Swift source must compile exactly once, and
# resource/framework labels must not leak into the wrong phase.
for bid in phase_members['Sources']:
    _file_ref, build_label, file_label = build_files[bid]
    if not (build_label.endswith('.swift in Sources') and file_label.endswith('.swift')):
        raise SystemExit(f'ERROR: non-Swift or mislabeled build file in Sources: {bid} {build_label}')
for bid in phase_members['Resources']:
    _file_ref, build_label, _file_label = build_files[bid]
    if not build_label.endswith(' in Resources'):
        raise SystemExit(f'ERROR: mislabeled build file in Resources: {bid} {build_label}')
for bid in phase_members['Frameworks']:
    _file_ref, build_label, _file_label = build_files[bid]
    if not build_label.endswith(' in Frameworks'):
        raise SystemExit(f'ERROR: mislabeled build file in Frameworks: {bid} {build_label}')

# Ensure the app target actually owns the critical build phases.
target_sec = section('PBXNativeTarget')
target = re.search(r'/\* pip_swift \*/\s*=\s*\{(.*?)\n\s*\};', target_sec, re.S)
if not target:
    raise SystemExit('ERROR: primary pip_swift PBXNativeTarget not found')
block = target.group(1)
for required_label in ('Sources', 'Frameworks', 'Resources', '[CP] Check Pods Manifest.lock', '[CP] Embed Pods Frameworks'):
    if f'/* {required_label} */' not in block:
        raise SystemExit('ERROR: primary target missing build phase: ' + required_label)
PYVERIFY



echo "[34/35] Verify deterministic CocoaPods/build-settings inheritance"
python3 - "$ROOT" "$PBX" <<'PYVERIFY'
import re
import sys
from pathlib import Path
root = Path(sys.argv[1])
pbx = Path(sys.argv[2]).read_text(errors='ignore')
ios = root / 'pip_swift'
lock = ios / 'Podfile.lock'
manifest = ios / 'Pods' / 'Manifest.lock'
if not lock.is_file() or not manifest.is_file():
    raise SystemExit('ERROR: vendored CocoaPods lock snapshot is missing')
if lock.read_bytes() != manifest.read_bytes():
    raise SystemExit('ERROR: Pods/Manifest.lock does not exactly match Podfile.lock')
for name in ('Pods-pip_swift.debug.xcconfig', 'Pods-pip_swift.release.xcconfig'):
    cfg = ios / 'Pods' / 'Target Support Files' / 'Pods-pip_swift' / name
    if not cfg.is_file():
        raise SystemExit('ERROR: missing CocoaPods xcconfig: ' + name)
    text = cfg.read_text(errors='ignore')
    required = {
        'FRAMEWORK_SEARCH_PATHS': '$(inherited)',
        'HEADER_SEARCH_PATHS': '$(inherited)',
        'LD_RUNPATH_SEARCH_PATHS': '$(inherited)',
        'OTHER_LDFLAGS': '$(inherited)',
        'OTHER_SWIFT_FLAGS': '$(inherited)',
    }
    for key, token in required.items():
        m = re.search(rf'^{re.escape(key)}\s*=\s*(.*)$', text, re.M)
        if not m or token not in m.group(1):
            raise SystemExit(f'ERROR: {name} does not preserve {key} inheritance')
for expected in ('Pods-pip_swift.debug.xcconfig', 'Pods-pip_swift.release.xcconfig'):
    if expected not in pbx:
        raise SystemExit('ERROR: app target is not wired to ' + expected)
for token in ('IPHONEOS_DEPLOYMENT_TARGET = 26.0;', 'TARGETED_DEVICE_FAMILY = 1;', 'SWIFT_VERSION = 5.0;'):
    if token not in pbx:
        raise SystemExit('ERROR: required app build setting missing: ' + token)
PYVERIFY

echo "[35/35] Enforce Xcode workspace/scheme preflight"
grep -q 'Preflight Xcode workspace and scheme' "$ROOT/scripts/build_unsigned_ipa.sh" || { echo "ERROR: missing Xcode workspace/scheme preflight"; exit 1; }
grep -q 'xcodebuild -list -workspace' "$ROOT/scripts/build_unsigned_ipa.sh" || { echo "ERROR: missing xcodebuild workspace listing preflight"; exit 1; }
grep -q 'xcodebuild -showBuildSettings' "$ROOT/scripts/build_unsigned_ipa.sh" || { echo "ERROR: missing resolved build-settings preflight"; exit 1; }

echo "Verification passed."


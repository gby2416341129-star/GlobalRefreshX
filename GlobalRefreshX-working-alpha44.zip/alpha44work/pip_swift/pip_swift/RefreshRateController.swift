import UIKit

/// Owns the single app-level refresh-rate request used by the PiP route.
/// Keeping this in one object prevents accidental duplicate CADisplayLinks.
final class RefreshRateController {
    static let shared = RefreshRateController()

    private var displayLink: CADisplayLink?
    private init() {}

    var isRunning: Bool { displayLink != nil }

    func reconcile() {
        let defaults = UserDefaults.standard
        let playerLayer = defaults.bool(forKey: "pip.home.playerLayerRouteEnabled")
        let extremeSilent = defaults.bool(forKey: "pip.home.extremeSilentModeEnabled")
        // When the user disables the global high-refresh request, fully release the
        // app-level display link instead of pinning an unnecessary 80 Hz request.
        // This keeps the disabled state truly system-adaptive and removes a 120/80 Hz
        // main-run-loop callback source that no longer serves the product goal.
        guard FrameRatePreference.isHighRefreshEnabled, !playerLayer, !extremeSilent else {
            stop()
            return
        }
        startOrUpdate()
    }

    func stop() {
        displayLink?.invalidate()
        displayLink = nil
    }

    private func startOrUpdate() {
        if let displayLink {
            configure(displayLink)
            return
        }
        let link = CADisplayLink(target: self, selector: #selector(step(_:)))
        configure(link)
        link.add(to: .main, forMode: .common)
        displayLink = link
    }

    private func configure(_ link: CADisplayLink) {
        let screenMaximum = max(60, UIScreen.main.maximumFramesPerSecond)
        let requested = min(FrameRatePreference.targetFrameRate, screenMaximum)
        let value = Float(requested)
        link.preferredFrameRateRange = CAFrameRateRange(
            minimum: value,
            maximum: value,
            preferred: value
        )
    }

    @objc private func step(_ link: CADisplayLink) {
        // Intentionally empty. The active display link is the refresh-rate request.
    }
}

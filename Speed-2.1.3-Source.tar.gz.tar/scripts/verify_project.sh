#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
pass=0
check() { if eval "$2"; then echo "PASS: $1"; pass=$((pass + 1)); else echo "FAIL: $1" >&2; exit 1; fi; }

PROJECT="pip_swift/pip_swift.xcodeproj/project.pbxproj"
APP="pip_swift/pip_swift"

check 'Speed version' "grep -q 'MARKETING_VERSION = 2.1.3' '$PROJECT'"
check 'Speed build number' "grep -q 'CURRENT_PROJECT_VERSION = 2026090868' '$PROJECT'"
check 'Speed bundle identifier' "grep -q 'PRODUCT_BUNDLE_IDENTIFIER = com.isil.speed' '$PROJECT'"
check 'Speed product name' "grep -q 'PRODUCT_NAME = Speed' '$PROJECT'"
check 'Automatic signing ready' "grep -q 'CODE_SIGN_STYLE = Automatic' '$PROJECT'"
check 'App display name' "grep -A1 '<key>CFBundleDisplayName</key>' '$APP/Info.plist' | grep -q '<string>Speed</string>'"
check 'No extension target' "! grep -q 'PBXNativeTarget.*Control\|Embed App Extensions\|GlobalRefreshControl' '$PROJECT'"
check 'No old pages' "test -z \"\$(find '$APP' \\( -name '*FrameRateTest*' -o -name 'VersionViewController.swift' -o -name 'TutorialTabBarController.swift' \\) -print)\""
check 'No shortcut bridge' "! grep -R -q -i 'PiPShortcut\|ControlCenterRuntimeState\|shortcutStartRetry' '$APP' --include='*.swift'"
check 'No network polling' "! grep -R -q -i 'NetworkTrafficSample\|URLSession' '$APP' --include='*.swift' && ! grep -q 'import Darwin' '$APP/ViewController.swift'"
check 'Single main screen' "! grep -q 'UITabBarController' '$APP/MainTabBarController.swift'"
check 'Settings stay expanded' "grep -q 'private var isSettingsExpanded = true' '$APP/ViewController.swift'"
check 'No elapsed time UI' "! grep -q 'pipRunningDuration' '$APP/PiPViews.swift'"
check 'Static PiP status text' "grep -q '120Hz 已启动' '$APP/ViewController.swift' && ! grep -q '悬浮窗运行中' '$APP/ViewController.swift'"
check 'No PiP tap-to-close handler' "! grep -q 'customView.addGestureRecognizer' '$APP/ViewController.swift'"
check 'Three independent PiP actions' "grep -q 'onHidePiP:' '$APP/PiPViews.swift' && grep -q 'onStartAndHidePiP:' '$APP/PiPViews.swift' && grep -q 'startPiPFromHome(autoHide: false)' '$APP/ViewController.swift' && grep -q 'startPiPFromHome(autoHide: true)' '$APP/ViewController.swift'"
check 'One-tap mode clears after start' "grep -q 'shouldAutoHideAfterNextStart = false' '$APP/ViewController.swift' && grep -q 'commitPiPHeight(self.currentMinimumPiPHeight)' '$APP/ViewController.swift'"
check 'Cache button is functional' "grep -q 'systemName: \"broom.fill\"' '$APP/PiPViews.swift' && grep -q 'CacheCleanupManager.clearManually' '$APP/ViewController.swift'"
check '120Hz minimum pin retained' "grep -R -q 'minimum: requested' '$APP' --include='*.swift'"
check '120Hz maximum pin retained' "grep -R -q 'maximum: requested' '$APP' --include='*.swift'"
check '120Hz preferred pin retained' "grep -R -q 'preferred: requested' '$APP' --include='*.swift'"
check 'Minimum frame duration plist retained' "grep -q 'CADisableMinimumFrameDurationOnPhone' '$APP/Info.plist'"
check 'No legacy product identity' "! grep -R -q -i 'globalrefresh\|yoroin\|caiwanfeng' --exclude=NOTICE --exclude=verify_project.sh --exclude-dir=Pods --exclude-dir=.git ."

echo "Verification passed: $pass/$pass"

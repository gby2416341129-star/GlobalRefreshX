import AppIntents
import Foundation
import SwiftUI
import WidgetKit

private enum RuntimeBridge {
    static let controlKind = "com.yoroin.globalrefresh.control.runtime.v3"
    static let startCommand = "com.yoroin.globalrefresh.control.v3.start"
    static let stopCommand = "com.yoroin.globalrefresh.control.v3.stop"
    static let query = "com.yoroin.globalrefresh.control.v3.query"
    static let runningResponse = "com.yoroin.globalrefresh.control.v3.running"
    static let stoppedResponse = "com.yoroin.globalrefresh.control.v3.stopped"

    private final class QueryBox {
        let semaphore = DispatchSemaphore(value: 0)
        private let lock = NSLock()
        private var storedResult: Bool?

        var result: Bool? {
            lock.lock(); defer { lock.unlock() }
            return storedResult
        }

        func finish(_ value: Bool) {
            lock.lock()
            guard storedResult == nil else { lock.unlock(); return }
            storedResult = value
            lock.unlock()
            semaphore.signal()
        }
    }

    private static let queryCallback: CFNotificationCallback = { _, observer, name, _, _ in
        guard let observer, let name else { return }
        let box = Unmanaged<QueryBox>.fromOpaque(observer).takeUnretainedValue()
        let rawName = name.rawValue as String
        if rawName == runningResponse {
            box.finish(true)
        } else if rawName == stoppedResponse {
            box.finish(false)
        }
    }

    static func liveRuntimeState(timeout: TimeInterval = 0.20) -> Bool {
        let box = QueryBox()
        let observer = Unmanaged.passUnretained(box).toOpaque()
        let center = CFNotificationCenterGetDarwinNotifyCenter()

        CFNotificationCenterAddObserver(center, observer, queryCallback, runningResponse as CFString, nil, .deliverImmediately)
        CFNotificationCenterAddObserver(center, observer, queryCallback, stoppedResponse as CFString, nil, .deliverImmediately)
        defer { CFNotificationCenterRemoveObserver(center, observer, nil, nil) }

        post(query)
        _ = box.semaphore.wait(timeout: .now() + timeout)
        return box.result ?? false
    }

    static func request(_ desired: Bool) {
        post(desired ? startCommand : stopCommand)
    }

    static func post(_ name: String) {
        CFNotificationCenterPostNotification(
            CFNotificationCenterGetDarwinNotifyCenter(),
            CFNotificationName(name as CFString),
            nil,
            nil,
            true
        )
    }
}

struct GlobalRefreshRuntimeControl: ControlWidget {
    static let kind = RuntimeBridge.controlKind

    var body: some ControlWidgetConfiguration {
        StaticControlConfiguration(kind: Self.kind, provider: Provider()) { isRunning in
            // Keep this identical to Apple's recommended control template.
            // The Label in valueLabel gives Control Center a native leading glyph
            // and lets the system own spacing/alignment for every control size.
            ControlWidgetToggle(
                "GlobalRefresh X",
                isOn: isRunning,
                action: SetGlobalRefreshRunningIntent(),
                valueLabel: { running in
                    Label(
                        running ? "运行中" : "未运行",
                        systemImage: running ? "bolt.horizontal.circle.fill" : "bolt.horizontal.circle"
                    )
                }
            )
        }
        .displayName("GlobalRefresh X")
        .description("查看并控制全局高刷。状态来自正在运行的 GlobalRefresh X 进程。")
    }

    struct Provider: ControlValueProvider {
        var previewValue: Bool { false }

        func currentValue() async throws -> Bool {
            // No cached preference is trusted. No host response == not running.
            RuntimeBridge.liveRuntimeState()
        }
    }
}

struct SetGlobalRefreshRunningIntent: SetValueIntent {
    static let title: LocalizedStringResource = "GlobalRefresh X"
    static let description = IntentDescription("启动或停止 GlobalRefresh X 高刷核心。")
    static let supportedModes: IntentModes = [.background, .foreground(.dynamic)]

    @Parameter(title: "运行中")
    var value: Bool

    func perform() async throws -> some IntentResult {
        // Fast path: when the host process is alive, Darwin notification reaches
        // it directly and requires no shared entitlement/container.
        RuntimeBridge.request(value)

        if value && !RuntimeBridge.liveRuntimeState(timeout: 0.12) {
            // Starting PiP needs the UIKit host. Ask iOS to foreground it when
            // possible, then send the command again after its scene registers.
            if systemContext.currentMode.canContinueInForeground {
                try await continueInForeground(IntentDialog("启动 GlobalRefresh X"), alwaysConfirm: false)
                try? await Task.sleep(for: .milliseconds(180))
                RuntimeBridge.request(true)
            }
        }

        // Give the host a short window to complete the command before WidgetKit
        // re-queries currentValue(). This is not a polling loop and is off the
        // 120 Hz rendering path.
        try? await Task.sleep(for: .milliseconds(value ? 220 : 80))
        return .result()
    }
}

@main
struct GlobalRefreshControlBundle: WidgetBundle {
    var body: some Widget {
        GlobalRefreshRuntimeControl()
    }
}

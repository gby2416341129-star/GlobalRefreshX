import Foundation
import WidgetKit

/// Runtime truth bridge for the iOS Control Center control.
///
/// Alpha55 deliberately does NOT require App Group storage for control commands
/// or status reads. The widget extension asks the live host process over Darwin
/// notifications. If the host is gone, there is no response and the control is
/// treated as stopped. This matches the product meaning of “运行中”.
enum ControlCenterRuntimeState {
    static let controlKind = "com.yoroin.globalrefresh.control.runtime.v3"

    static let startCommandNotification = "com.yoroin.globalrefresh.control.v3.start"
    static let stopCommandNotification = "com.yoroin.globalrefresh.control.v3.stop"
    static let queryNotification = "com.yoroin.globalrefresh.control.v3.query"
    static let runningResponseNotification = "com.yoroin.globalrefresh.control.v3.running"
    static let stoppedResponseNotification = "com.yoroin.globalrefresh.control.v3.stopped"

    private static let stateQueue = DispatchQueue(label: "com.yoroin.globalrefresh.control-runtime-state")
    private static var runtimeRunning = false

    static var isRuntimeRunning: Bool {
        stateQueue.sync { runtimeRunning }
    }

    static func markRunning() {
        stateQueue.sync { runtimeRunning = true }
        reloadControl()
    }

    static func markStopped() {
        stateQueue.sync { runtimeRunning = false }
        reloadControl()
    }

    static func respondToRuntimeQuery() {
        postDarwin(isRuntimeRunning ? runningResponseNotification : stoppedResponseNotification)
    }

    static func postDarwin(_ name: String) {
        CFNotificationCenterPostNotification(
            CFNotificationCenterGetDarwinNotifyCenter(),
            CFNotificationName(name as CFString),
            nil,
            nil,
            true
        )
    }

    private static func reloadControl() {
        Task { @MainActor in
            ControlCenter.shared.reloadControls(ofKind: controlKind)
        }
    }
}

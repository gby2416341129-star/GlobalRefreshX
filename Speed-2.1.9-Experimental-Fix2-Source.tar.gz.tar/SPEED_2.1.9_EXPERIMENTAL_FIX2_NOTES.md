# Speed 2.1.9 Experimental Fix2

Build: 2026090903

Runtime launch hotfix:
- Removes UIUpdateLink from the app launch/runtime path after an on-device immediate-launch crash report on iOS 27.0.
- Retains the stable hard-max CADisplayLink standard-mode request.
- Retains Experimental compatibility mode 60 Hz activity driver, 60 fps low-pixel H.264 media, immediate AVPlayer playback policy, and recovery behavior.
- Retains the iOS 27 top-right Liquid Glass ghost/halo UI fix.

This is intentionally still the single aggressive experimental branch; only the suspected crash-inducing launch hook is removed.

import UIKit

/// A deliberately thin root container. Speed has one job, so it no longer pays
/// the layout and transition cost of a tab bar or keeps inactive pages alive.
final class MainTabBarController: UIViewController {
    private let speedController = ViewController()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGroupedBackground

        addChild(speedController)
        view.addSubview(speedController.view)
        speedController.view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            speedController.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            speedController.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            speedController.view.topAnchor.constraint(equalTo: view.topAnchor),
            speedController.view.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        speedController.didMove(toParent: self)

        RefreshRateController.shared.reconcile()
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleDidBecomeActive),
            name: UIApplication.didBecomeActiveNotification,
            object: nil
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleDidEnterBackground),
            name: UIApplication.didEnterBackgroundNotification,
            object: nil
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleEngineModeChange),
            name: ViewController.piPEngineRuntimeModeDidChangeNotification,
            object: nil
        )
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
        RefreshRateController.shared.stop()
    }

    @objc private func handleDidBecomeActive() {
        RefreshRateController.shared.reconcile()
        DebugDiagnosticsMonitor.startIfNeeded()
    }

    @objc private func handleDidEnterBackground() {
        // Diagnostics are optional. The PiP engine and the single empty
        // display-link callback remain the only high-frequency background work.
        DebugDiagnosticsMonitor.stop()
        RefreshRateController.shared.reconcile()
    }

    @objc private func handleEngineModeChange() {
        RefreshRateController.shared.reconcile()
    }
}

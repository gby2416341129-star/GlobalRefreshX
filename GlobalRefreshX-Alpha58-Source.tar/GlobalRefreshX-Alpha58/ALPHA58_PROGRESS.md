# GlobalRefresh X Alpha58

Control Center implementation rebuilt from Apple's documented ControlWidgetToggle pattern.

- Version: 2.0.0-alpha58
- Build: 2026090862
- Control kind: com.yoroin.globalrefresh.control.runtime.v6
- Shared SetValueIntent source is compiled into both app and widget-extension targets.
- ControlValueProvider reads only last confirmed PiP runtime state from App Group.
- PiP didStart/didStop remains the source of truth and triggers ControlCenter reload.
- Darwin notifications are command-only; no synchronous live-state query.
- Control UI uses title + valueLabel Label with SF Symbol, matching Apple's documented timer example.

//
//  SceneDelegate.swift
//  pip_swift
//
//  Created by 无夜之星辰 on 2021/5/26.
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    private static let controlBridgeCallback: CFNotificationCallback = { _, observer, name, _, _ in
        guard let observer, let name else { return }
        let delegate = Unmanaged<SceneDelegate>.fromOpaque(observer).takeUnretainedValue()
        let rawName = name.rawValue as String
        DispatchQueue.main.async {
            delegate.handleControlBridgeNotification(rawName)
        }
    }


    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene else { return }

        let window = UIWindow(windowScene: windowScene)
        window.rootViewController = MainTabBarController()
        AppAppearancePreference.apply(to: window)
        self.window = window
        window.makeKeyAndVisible()

        ControlCenterRuntimeState.markStopped()
        registerControlCenterBridge()

        handleShortcutURLContexts(connectionOptions.urlContexts)

    }

    deinit {
        CFNotificationCenterRemoveObserver(
            CFNotificationCenterGetDarwinNotifyCenter(),
            Unmanaged.passUnretained(self).toOpaque(),
            nil,
            nil
        )
    }

    func sceneDidDisconnect(_ scene: UIScene) {
        // Called as the scene is being released by the system.
        // This occurs shortly after the scene enters the background, or when its session is discarded.
        // Release any resources associated with this scene that can be re-created the next time the scene connects.
        // The scene may re-connect later, as its session was not necessarily discarded (see `application:didDiscardSceneSessions` instead).
    }

    func sceneDidBecomeActive(_ scene: UIScene) {
        // Control Center uses live Darwin commands; no cached command replay is needed.
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
        print("sceneDidEnterBackground")
    }

    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        handleShortcutURLContexts(URLContexts)
    }

    private func registerControlCenterBridge() {
        let center = CFNotificationCenterGetDarwinNotifyCenter()
        let observer = Unmanaged.passUnretained(self).toOpaque()
        for name in [
            ControlCenterRuntimeState.startCommandNotification,
            ControlCenterRuntimeState.stopCommandNotification
        ] {
            CFNotificationCenterAddObserver(
                center,
                observer,
                Self.controlBridgeCallback,
                name as CFString,
                nil,
                .deliverImmediately
            )
        }
    }

    private func handleControlBridgeNotification(_ name: String) {
        switch name {
        case ControlCenterRuntimeState.startCommandNotification:
            (window?.rootViewController as? MainTabBarController)?
                .handleSystemControlRequest(desiredRunning: true)
        case ControlCenterRuntimeState.stopCommandNotification:
            (window?.rootViewController as? MainTabBarController)?
                .handleSystemControlRequest(desiredRunning: false)
        default:
            break
        }
    }

    private func handleShortcutURLContexts(_ URLContexts: Set<UIOpenURLContext>) {
        for context in URLContexts {
            if PiPShortcutActionCenter.request(from: context.url) {
                (window?.rootViewController as? MainTabBarController)?
                    .handleExternalShortcutRequest(reason: "URL快捷指令")
                break
            }
        }
    }

}

import Foundation
import WidgetKit

/// Main-app source of truth for the Control Center state.
/// Only confirmed PiP lifecycle callbacks update this value.
enum ControlCenterRuntimeState {
    static let controlKind = GlobalRefreshControlSharedState.controlKind
    static let startCommandNotification = GlobalRefreshControlSharedState.startCommand
    static let stopCommandNotification = GlobalRefreshControlSharedState.stopCommand

    private static let stateQueue = DispatchQueue(label: "com.yoroin.globalrefresh.control-runtime-state")
    private static var runtimeRunning = false

    static var isRuntimeRunning: Bool {
        stateQueue.sync { runtimeRunning }
    }

    static func markRunning() {
        stateQueue.sync { runtimeRunning = true }
        GlobalRefreshControlSharedState.setActualRunning(true)
        reloadControl()
    }

    static func markStopped() {
        stateQueue.sync { runtimeRunning = false }
        GlobalRefreshControlSharedState.setActualRunning(false)
        reloadControl()
    }

    private static func reloadControl() {
        Task { @MainActor in
            ControlCenter.shared.reloadControls(ofKind: controlKind)
        }
    }
}

import AppIntents
import Foundation

/// Shared by both the main app target and the Control Widget extension target.
/// This follows Apple's Control/AppIntent model: one SetValueIntent type is
/// compiled into both targets, while App Group storage is used only for the
/// last confirmed runtime state.
enum GlobalRefreshControlSharedState {
    static let appGroupIdentifier = "group.com.yoroin.globalrefresh.shared"
    static let controlKind = "com.yoroin.globalrefresh.control.runtime.v6"
    static let actualRunningKey = "control.actualRunning.v6"
    static let startCommand = "com.yoroin.globalrefresh.control.v6.start"
    static let stopCommand = "com.yoroin.globalrefresh.control.v6.stop"

    static var actualRunning: Bool {
        UserDefaults(suiteName: appGroupIdentifier)?.bool(forKey: actualRunningKey) ?? false
    }

    static func setActualRunning(_ running: Bool) {
        UserDefaults(suiteName: appGroupIdentifier)?.set(running, forKey: actualRunningKey)
    }

    static func postCommand(desiredRunning: Bool) {
        let name = desiredRunning ? startCommand : stopCommand
        CFNotificationCenterPostNotification(
            CFNotificationCenterGetDarwinNotifyCenter(),
            CFNotificationName(name as CFString),
            nil,
            nil,
            true
        )
    }
}

struct SetGlobalRefreshRunningIntent: SetValueIntent {
    static let title: LocalizedStringResource = "GlobalRefresh X"
    static let description = IntentDescription("启动或停止 GlobalRefresh X 高刷核心。")
    static let supportedModes: IntentModes = [.background, .foreground(.dynamic)]

    @Parameter(title: "运行中")
    var value: Bool

    func perform() async throws -> some IntentResult {
        // First make sure the app process is available. Darwin notifications
        // alone cannot wake a suspended/terminated UIKit host.
        if systemContext.currentMode == .background,
           systemContext.currentMode.canContinueInForeground {
            try await continueInForeground(
                IntentDialog(value ? "启动 GlobalRefresh X" : "停止 GlobalRefresh X"),
                alwaysConfirm: false
            )
        }

        GlobalRefreshControlSharedState.postCommand(desiredRunning: value)
        return .result()
    }
}

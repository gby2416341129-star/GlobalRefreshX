import SwiftUI
import WidgetKit

struct GlobalRefreshRuntimeControl: ControlWidget {
    static let kind = GlobalRefreshControlSharedState.controlKind

    var body: some ControlWidgetConfiguration {
        StaticControlConfiguration(kind: Self.kind, provider: Provider()) { isRunning in
            // Mirrors Apple's documented timer-toggle shape: title is the
            // control title; the value label supplies both status and SF Symbol.
            ControlWidgetToggle(
                "GlobalRefresh X",
                isOn: isRunning,
                action: SetGlobalRefreshRunningIntent()
            ) { running in
                Label(
                    running ? "运行中" : "未运行",
                    systemImage: running ? "bolt.circle.fill" : "bolt.circle"
                )
            }
        }
        .displayName("GlobalRefresh X")
        .description("查看并控制全局高刷。")
    }

    struct Provider: ControlValueProvider {
        var previewValue: Bool { false }

        func currentValue() async throws -> Bool {
            GlobalRefreshControlSharedState.actualRunning
        }
    }
}

@main
struct GlobalRefreshControlBundle: WidgetBundle {
    var body: some Widget {
        GlobalRefreshRuntimeControl()
    }
}

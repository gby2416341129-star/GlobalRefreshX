import UIKit

/// Owns the single app-level refresh-rate request used by the PiP route.
/// Keeping this in one object prevents accidental duplicate CADisplayLinks.
final class RefreshRateController {
    static let shared = RefreshRateController()

    private var displayLink: CADisplayLink?
    private init() {}

    var isRunning: Bool { displayLink != nil }

    func reconcile() {
        let defaults = UserDefaults.standard
        let playerLayer = defaults.bool(forKey: "pip.home.playerLayerRouteEnabled")
        let extremeSilent = defaults.bool(forKey: "pip.home.extremeSilentModeEnabled")
        // When the user disables the global high-refresh request, fully release the
        // app-level display link instead of pinning an unnecessary 80 Hz request.
        // This keeps the disabled state truly system-adaptive and removes a 120/80 Hz
        // main-run-loop callback source that no longer serves the product goal.
        guard FrameRatePreference.isHighRefreshEnabled, !playerLayer, !extremeSilent else {
            stop()
            return
        }
        startOrUpdate()
    }

    func stop() {
        displayLink?.invalidate()
        displayLink = nil
    }

    private func startOrUpdate() {
        if let displayLink {
            configure(displayLink)
            return
        }
        let link = CADisplayLink(target: self, selector: #selector(step(_:)))
        configure(link)
        link.add(to: .main, forMode: .common)
        displayLink = link
    }

    private func configure(_ link: CADisplayLink) {
        let screenMaximum = max(60, UIScreen.main.maximumFramesPerSecond)
        let requestedMaximum = Float(min(FrameRatePreference.targetFrameRate, screenMaximum))

        // Alpha47-r1 Adaptive Boost:
        // Keep 120 Hz available without continuously pinning the display link to 120/120/120.
        // A background PiP app cannot observe touch/scroll events that occur inside another app,
        // so the only public-API-safe way to get "idle low / interaction high" system-wide is
        // to expose a wide ProMotion range and let iOS perform the interaction-driven ramp.
        //
        // minimum = 1: allows the scheduler to descend to the lowest cadence supported by
        //              the current device/policy (for example 10 Hz on hardware that cannot do 1 Hz).
        // maximum = 120: keeps full ProMotion available during scrolling/animations.
        // preferred = 0: avoids a permanent 120 Hz preference while idle; iOS chooses cadence.
        link.preferredFrameRateRange = CAFrameRateRange(
            minimum: 1,
            maximum: requestedMaximum,
            preferred: 0
        )
    }

    @objc private func step(_ link: CADisplayLink) {
        // Intentionally empty. The active display link is the refresh-rate request.
    }
}

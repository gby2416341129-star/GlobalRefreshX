import UIKit

/// Experimental aggressive refresh policy for iOS 26/27.
///
/// Standard / VideoCall route:
/// - one empty hard-max CADisplayLink on `.common` remains the foreground/background/PiP anchor;
/// - deliberately avoids UIUpdateLink on iOS 27.0 because the system-level update hook is
///   too early/fragile for a sideloaded app launch path and can terminate the process before UI appears.
///
/// Compatibility / PlayerLayer route releases the app-level hard-max display link so the
/// media cadence can arbitrate without competing with the Standard route policy.
enum FrameRatePreference {
    static let didChangeNotification = Notification.Name("speed.refreshRatePolicyDidChange")
    static var isHighRefreshEnabled: Bool { true }
    static var targetFrameRate: Int { min(120, AppDisplayContext.maximumFramesPerSecond) }

    static func preferredFrameRateValue(target: Float) -> Float { target }
}

enum RefreshRuntimeMode: Equatable {
    case videoCall
    case playerLayer
}

enum AppDisplayContext {
    static var activeWindowScene: UIWindowScene? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        return scenes.first(where: { $0.activationState == .foregroundActive })
            ?? scenes.first(where: { $0.activationState == .foregroundInactive })
            ?? scenes.first
    }

    static var screen: UIScreen? { activeWindowScene?.screen }
    static var bounds: CGRect { screen?.bounds ?? .zero }
    static var scale: CGFloat { max(screen?.scale ?? 1, 1) }
    static var maximumFramesPerSecond: Int { max(screen?.maximumFramesPerSecond ?? 60, 60) }
}

@MainActor
final class RefreshRateController {
    static let shared = RefreshRateController()

    private var displayLink: CADisplayLink?
    private var configuredFrameRate: Float = 0
    private(set) var runtimeMode: RefreshRuntimeMode = .videoCall

    private init() {}

    var isRunning: Bool { displayLink != nil }

    func setRuntimeMode(_ mode: RefreshRuntimeMode) {
        guard runtimeMode != mode else {
            reconcile()
            return
        }
        runtimeMode = mode
        reconcile()
    }

    func reconcile() {
        guard FrameRatePreference.isHighRefreshEnabled, runtimeMode == .videoCall else {
            stop()
            return
        }
        startOrUpdateHardMaxDisplayLink()
    }

    func stop() {
        displayLink?.invalidate()
        displayLink = nil
        configuredFrameRate = 0
    }

    private func startOrUpdateHardMaxDisplayLink() {
        let requested = requestedFrameRate()
        if let displayLink {
            if configuredFrameRate != requested {
                configure(displayLink, requested: requested)
            }
            if displayLink.isPaused { displayLink.isPaused = false }
            return
        }

        let link = CADisplayLink(target: self, selector: #selector(step(_:)))
        configure(link, requested: requested)
        link.add(to: .main, forMode: .common)
        link.isPaused = false
        displayLink = link
    }

    private func requestedFrameRate() -> Float {
        Float(min(FrameRatePreference.targetFrameRate, AppDisplayContext.maximumFramesPerSecond))
    }

    private func configure(_ link: CADisplayLink, requested: Float) {
        link.preferredFrameRateRange = CAFrameRateRange(
            minimum: requested,
            maximum: requested,
            preferred: requested
        )
        configuredFrameRate = requested
    }

    @objc private func step(_ link: CADisplayLink) {
        // Intentionally empty. Any main-thread work here steals from the 8.33 ms budget.
    }
}

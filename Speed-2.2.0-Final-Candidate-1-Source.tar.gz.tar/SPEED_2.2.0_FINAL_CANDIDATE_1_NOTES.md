# Speed 2.2.0 Final Candidate 1

Build: `2026090904`

## Compatibility mode rollback

The 2.1.9 experiment did not improve perceived smoothness on the target device, so Compatibility mode is returned to the earlier stable strategy:

- 30 fps PlayerLayer backing media.
- 60-second low-pixel cached geometry video.
- Event-driven AVPlayer recovery.
- No extra 60 Hz PlayerLayer `CADisplayLink`.
- No `playImmediately(atRate:)` forcing.

## Compatibility PiP size fixes

- Fixed stale style state: Compatibility compact/default height is now 22 pt, not the Standard mode 44 pt value.
- Floating-style toggle is derived from current requested geometry on every tap instead of trusting a stale Boolean.
- Compatibility style now toggles 22 pt <-> 120 pt.
- One-tap 1 pt minimum is transient and does not overwrite the remembered normal height.
- Closing after a 1 pt hide restores 22 pt default geometry and replaces the PlayerLayer backing item.
- Normal reopening from a minimum state restores the actual PlayerLayer media geometry before PiP start retries.
- Height slider preview now debounces media-aspect updates, because PlayerLayer PiP ignores source-view-only resizing.
- Height editor reset is route-aware: 22 pt in Compatibility mode, 44 pt in Standard mode.

## UI and startup fixes retained

- Retains the iOS 27 single-layer Liquid Glass fix for the two top circular controls.
- Retains the SceneDelegate/MainActor startup crash fix.
- Retains removal of the experimental `UIUpdateLink` startup hook.

## Validation

- Project policy checks: 53/53.
- All Swift files parse in normal and DEBUG configurations with Swift 6.2.1 frontend.
- Shell scripts pass syntax validation.

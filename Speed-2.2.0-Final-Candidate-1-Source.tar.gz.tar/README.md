# Speed

Speed is an iPhone Picture-in-Picture utility focused on a responsive high-refresh presentation path on supported devices running iOS 26 or later.

## Speed 2.2.0 Final Candidate 1

This candidate freezes the first production strategy set:

- Standard mode keeps the proven hard-maximum `CADisplayLink` refresh request.
- Compatibility mode is reverted to the known-good 30 fps low-pixel PlayerLayer media cadence; the experimental 60 Hz activity assist and 60 fps media path are removed.
- Compatibility PiP geometry is media-driven and now has a single route-aware size state.
- One-tap minimum is transient in Compatibility mode, so closing and reopening restores the normal 22 pt default instead of reusing the 1 pt backing geometry.
- Floating-style switching uses 22 pt <-> 120 pt in Compatibility mode and 44 pt <-> 120 pt in Standard mode.
- The height editor uses the correct per-mode default and debounces PlayerLayer media-aspect updates while dragging.
- The iOS 27 top-button Liquid Glass halo/ghost artifact fix is retained.
- The fragile `UIUpdateLink` startup experiment remains removed.

## Build an unsigned IPA

Run `./scripts/build_unsigned_ipa.sh` on macOS with Xcode 26 or later. The IPA is written to `dist/Speed-unsigned.ipa`; sign it using your preferred personal signing workflow before installing.

The project requires iOS 26 or later. Keep the included `NOTICE` when copying or redistributing this derivative source tree.

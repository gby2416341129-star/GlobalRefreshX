import Foundation

/// 管理一次 PiP 启动/停止事务的唯一状态源。
///
/// 这里只记录“正在做什么”，不直接调用 AVKit。这样可以避免 ViewController
/// 同时维护多个布尔值、时间戳和原因字符串而产生互相矛盾的状态。
final class PiPTransitionCoordinator {
    struct Snapshot: Equatable {
        let sequence: UInt64
        let startedAt: Date
        let reason: String
        let expectedActive: Bool
    }

    private(set) var snapshot: Snapshot?
    private var nextSequence: UInt64 = 0

    var isTransitioning: Bool { snapshot != nil }
    var startedAt: Date? { snapshot?.startedAt }
    var reason: String { snapshot?.reason ?? "未知" }
    var expectedActive: Bool? { snapshot?.expectedActive }

    @discardableResult
    func begin(expectedActive: Bool, reason: String) -> Snapshot {
        nextSequence &+= 1
        let value = Snapshot(
            sequence: nextSequence,
            startedAt: Date(),
            reason: reason,
            expectedActive: expectedActive
        )
        snapshot = value
        AppDebugLogger.log(
            "PiP 事务 #\(value.sequence) 开始：expectedActive=\(expectedActive), reason=\(reason)"
        )
        return value
    }

    @discardableResult
    func finish() -> Snapshot? {
        let old = snapshot
        snapshot = nil
        if let old {
            let elapsed = Date().timeIntervalSince(old.startedAt)
            AppDebugLogger.log(
                "PiP 事务 #\(old.sequence) 结束：耗时=\(String(format: "%.2f", elapsed))s, reason=\(old.reason)"
            )
        }
        return old
    }
}

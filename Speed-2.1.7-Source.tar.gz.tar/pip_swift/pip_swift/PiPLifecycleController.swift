import AVKit
import Foundation

/// Small, deterministic state machine for PiP lifecycle transitions.
///
/// It deliberately does not own AVPictureInPictureController yet; instead it
/// centralizes lifecycle truth so UI state, recovery logic and diagnostics do
/// not have to infer state from several booleans spread across ViewController.
final class PiPLifecycleController {
    enum State: Equatable, CustomStringConvertible {
        case idle
        case starting(reason: String)
        case active(startedAt: Date)
        case stopping(reason: String)
        case failed(message: String)

        var description: String {
            switch self {
            case .idle:
                return "idle"
            case .starting(let reason):
                return "starting(\(reason))"
            case .active:
                return "active"
            case .stopping(let reason):
                return "stopping(\(reason))"
            case .failed(let message):
                return "failed(\(message))"
            }
        }
    }

    private(set) var state: State = .idle
    private(set) var transitionSequence: UInt64 = 0
    private(set) var lastTransitionAt = Date()

    var isActive: Bool {
        if case .active = state { return true }
        return false
    }

    var isTransitioning: Bool {
        switch state {
        case .starting, .stopping:
            return true
        default:
            return false
        }
    }

    @discardableResult
    func willStart(reason: String) -> UInt64 {
        transition(to: .starting(reason: reason))
    }

    @discardableResult
    func didStart() -> UInt64 {
        transition(to: .active(startedAt: Date()))
    }

    @discardableResult
    func willStop(reason: String) -> UInt64 {
        transition(to: .stopping(reason: reason))
    }

    @discardableResult
    func didStop() -> UInt64 {
        transition(to: .idle)
    }

    @discardableResult
    func didFail(_ error: Error) -> UInt64 {
        transition(to: .failed(message: error.localizedDescription))
    }

    @discardableResult
    func reset() -> UInt64 {
        transition(to: .idle)
    }

    @discardableResult
    private func transition(to newState: State) -> UInt64 {
        state = newState
        transitionSequence &+= 1
        lastTransitionAt = Date()
        AppDebugLogger.log("PiP lifecycle #\(transitionSequence): \(newState.description)")
        return transitionSequence
    }
}

import UIKit

/// Speed has no frame-rate laboratory UI. The production policy is fixed:
/// request the display's supported maximum and keep it out of user defaults.
enum FrameRatePreference {
    static let didChangeNotification = Notification.Name("speed.refreshRatePolicyDidChange")
    static var isHighRefreshEnabled: Bool { true }
    static var targetFrameRate: Int { min(120, AppDisplayContext.maximumFramesPerSecond) }

    static func preferredFrameRateValue(target: Float) -> Float {
        target
    }
}

/// Owns the single app-level hard maximum-refresh request used by the VideoCall PiP route.
/// The hot path is intentionally minimal: one CADisplayLink, one empty callback,
/// and no per-frame logging, sampling, UI mutation, allocation, or timer work.
enum AppDisplayContext {
    static var activeWindowScene: UIWindowScene? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        return scenes.first(where: { $0.activationState == .foregroundActive })
            ?? scenes.first(where: { $0.activationState == .foregroundInactive })
            ?? scenes.first
    }

    static var screen: UIScreen? { activeWindowScene?.screen }
    static var bounds: CGRect { screen?.bounds ?? .zero }
    static var scale: CGFloat { max(screen?.scale ?? 1, 1) }
    static var maximumFramesPerSecond: Int { max(screen?.maximumFramesPerSecond ?? 60, 60) }
}

final class RefreshRateController {
    static let shared = RefreshRateController()

    private var displayLink: CADisplayLink?
    private var configuredFrameRate: Float = 0

    private init() {}

    var isRunning: Bool { displayLink != nil }

    func reconcile() {
        let defaults = UserDefaults.standard
        let playerLayer = defaults.bool(forKey: "pip.home.playerLayerRouteEnabled")
        let extremeSilent = defaults.bool(forKey: "pip.home.extremeSilentModeEnabled")

        // The PlayerLayer route intentionally keeps its original compatibility cadence.
        // The VideoCall route is the hard-max path.
        guard FrameRatePreference.isHighRefreshEnabled, !playerLayer, !extremeSilent else {
            stop()
            return
        }
        startOrUpdate()
    }

    func stop() {
        displayLink?.invalidate()
        displayLink = nil
        configuredFrameRate = 0
    }

    private func startOrUpdate() {
        let requested = requestedFrameRate()

        if let displayLink {
            // Avoid repeatedly mutating the frame-rate preference when nothing changed.
            // Reconfiguration is lifecycle-driven, not per-frame.
            if configuredFrameRate != requested {
                configure(displayLink, requested: requested)
            }
            if displayLink.isPaused {
                displayLink.isPaused = false
            }
            return
        }

        let link = CADisplayLink(target: self, selector: #selector(step(_:)))
        configure(link, requested: requested)
        link.add(to: .main, forMode: .common)
        link.isPaused = false
        displayLink = link
    }

    private func requestedFrameRate() -> Float {
        // iOS 26+: derive display capability from the scene that owns the UI.
        // Avoid the deprecated global-screen singleton; use scene context instead.
        let screenMaximum = AppDisplayContext.maximumFramesPerSecond
        return Float(min(FrameRatePreference.targetFrameRate, screenMaximum))
    }

    private func configure(_ link: CADisplayLink, requested: Float) {
        // Speed policy: hard-pin min/max/preferred to the supported maximum.
        // There is deliberately no adaptive lower range here.
        link.preferredFrameRateRange = CAFrameRateRange(
            minimum: requested,
            maximum: requested,
            preferred: requested
        )
        configuredFrameRate = requested
    }

    @objc private func step(_ link: CADisplayLink) {
        // Intentionally empty. Any work here steals time from the 8.33 ms frame budget.
    }
}

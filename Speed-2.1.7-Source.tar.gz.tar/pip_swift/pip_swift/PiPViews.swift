import SwiftUI
import UIKit

/// Speed's single-screen control surface. It intentionally contains no live
/// frame sampler, network reader, update checker, or continuously animated view.
struct PiPHomeView: View {
    @Binding var isPiPActive: Bool

    let presentationState: HomePresentationState
    let pipHeight: String
    let isCurrentAppearanceDark: Bool
    let pipEngineRoute: PiPEngineRoute
    let onTogglePiP: () -> Void
    let onHidePiP: () -> Void
    let onStartAndHidePiP: () -> Void
    let onToggleStyle: () -> Void
    let onCustomizeHeight: () -> Void
    let onToggleAppearanceMode: () -> Void
    let onClearCache: () -> Void
    let onSetPiPEngineRoute: (PiPEngineRoute) -> Void

    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        ZStack {
            SpeedBackground().ignoresSafeArea()

            GeometryReader { proxy in
                ScrollView(showsIndicators: false) {
                    VStack(spacing: proxy.size.height < 700 ? 15 : 20) {
                        header
                        statusCard
                        controls
                        settingsCard
                        Spacer(minLength: 8)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, max(proxy.safeAreaInsets.top + 10, 18))
                    .padding(.bottom, max(proxy.safeAreaInsets.bottom + 18, 26))
                    .frame(minHeight: proxy.size.height, alignment: .top)
                }
                .scrollBounceBehavior(.basedOnSize)
            }
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 3) {
                Text("Speed")
                    .font(.system(size: 34, weight: .bold, design: .rounded))
                    .tracking(-1.1)
                Text(L10n.text("让每一次滑动都更跟手", "Smoother motion, instantly"))
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(.secondary)
            }

            Spacer(minLength: 8)

            headerActions

        }
    }


    @ViewBuilder
    private var headerActions: some View {
        if #available(iOS 26.0, *) {
            GlassEffectContainer(spacing: 8) {
                HStack(spacing: 8) {
                    cacheCleanupButton
                    iconButton(
                        systemName: isCurrentAppearanceDark ? "sun.max.fill" : "moon.fill",
                        accessibilityLabel: L10n.text("切换外观", "Change appearance"),
                        action: onToggleAppearanceMode
                    )
                }
            }
        } else {
            HStack(spacing: 8) {
                cacheCleanupButton
                iconButton(
                    systemName: isCurrentAppearanceDark ? "sun.max.fill" : "moon.fill",
                    accessibilityLabel: L10n.text("切换外观", "Change appearance"),
                    action: onToggleAppearanceMode
                )
            }
        }
    }

    private var statusCard: some View {
        SpeedGlassCard {
            VStack(alignment: .leading, spacing: 18) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 0) {
                        HStack(alignment: .firstTextBaseline, spacing: 6) {
                            Text("\(presentationState.requestedFrameRate)")
                                .font(.system(size: 58, weight: .semibold, design: .rounded))
                                .monospacedDigit()
                                .contentTransition(reduceMotion ? .identity : .numericText())
                            Text("Hz")
                                .font(.title3.weight(.semibold))
                                .foregroundStyle(.secondary)
                        }
                        Text(L10n.text("目标刷新率", "Target refresh rate"))
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.tertiary)
                    }

                    Spacer(minLength: 12)

                    Image(systemName: presentationState.statusSystemImage)
                        .font(.system(size: 24, weight: .semibold))
                        .foregroundStyle(isPiPActive ? Color.cyan : Color.secondary)
                        .frame(width: 50, height: 50)
                        .background(.thinMaterial, in: Circle())
                }

                HStack(spacing: 10) {
                    Circle()
                        .fill(isPiPActive ? Color.green : Color.secondary.opacity(0.55))
                        .frame(width: 8, height: 8)
                    Text(localizedStatusTitle)
                        .font(.headline)
                    Spacer()
                }
            }
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(localizedStatusTitle), \(presentationState.requestedFrameRate) Hz")
    }

    private var controls: some View {
        Group {
            if #available(iOS 26.0, *) {
                GlassEffectContainer(spacing: 12) {
                    controlsContent
                }
            } else {
                controlsContent
            }
        }
        .animation(reduceMotion ? nil : .smooth(duration: 0.38), value: presentationState.activity)
        .animation(reduceMotion ? nil : .smooth(duration: 0.38), value: isPiPActive)
    }

    private var controlsContent: some View {
        VStack(spacing: 12) {
            Button(action: withHaptic(onTogglePiP)) {
                HStack(spacing: 10) {
                    Image(systemName: presentationState.primaryActionSystemImage)
                        .foregroundStyle(Color.cyan)
                        .contentTransition(.symbolEffect(.replace))
                    Text(primaryActionTitle)
                        .foregroundStyle(.primary)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.secondary)
                        .opacity(0.68)
                }
                .font(.headline)
                .padding(.horizontal, 18)
                .frame(maxWidth: .infinity, minHeight: 58)
                .background(SpeedGlassSurface(cornerRadius: 19, isInteractive: true))
            }
            .buttonStyle(SpeedPressButtonStyle())
            .disabled(!presentationState.allowsPrimaryAction)

            HStack(spacing: 12) {
                secondaryControlButton(
                    title: L10n.text("隐藏到最小", "Hide"),
                    systemName: "eye.slash.fill",
                    enabled: presentationState.allowsHideAction,
                    action: onHidePiP
                )
                secondaryControlButton(
                    title: L10n.text("启动并隐藏", "Start & Hide"),
                    systemName: "play.circle.fill",
                    enabled: presentationState.allowsPrimaryAction || presentationState.allowsHideAction,
                    action: onStartAndHidePiP
                )
            }
        }
    }

    private func secondaryControlButton(
        title: String,
        systemName: String,
        enabled: Bool,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: withHaptic(action)) {
            VStack(spacing: 7) {
                Image(systemName: systemName)
                    .font(.system(size: 17, weight: .semibold))
                Text(title)
                    .font(.subheadline.weight(.semibold))
                    .lineLimit(1)
                    .minimumScaleFactor(0.82)
            }
            .foregroundStyle(enabled ? Color.primary : Color.secondary)
            .frame(maxWidth: .infinity, minHeight: 60)
            .background(SpeedGlassSurface(cornerRadius: 18, isInteractive: true))
        }
        .buttonStyle(SpeedPressButtonStyle())
        .disabled(!enabled)
    }

    private var settingsCard: some View {
        SpeedGlassCard {
            VStack(spacing: 0) {
                settingButton(
                    title: L10n.text("悬浮窗样式", "Floating style"),
                    value: L10n.text("轻点切换", "Tap to change"),
                    systemName: "rectangle.compress.vertical",
                    action: onToggleStyle
                )
                divider
                settingButton(
                    title: L10n.text("悬浮窗高度", "PiP height"),
                    value: pipHeight,
                    systemName: "arrow.up.and.down",
                    action: onCustomizeHeight
                )
                divider
                enginePicker
            }
        }
    }

    private var enginePicker: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label(L10n.text("运行模式", "Engine mode"), systemImage: "cpu")
                .font(.subheadline.weight(.semibold))

            HStack(spacing: 8) {
                engineButton(
                    title: L10n.text("标准", "Standard"),
                    route: .videoCall
                )
                engineButton(
                    title: L10n.text("兼容", "Compatible"),
                    route: .playerLayerGenerated
                )
            }
        }
        .padding(.vertical, 15)
    }

    private func engineButton(title: String, route: PiPEngineRoute) -> some View {
        let selected = pipEngineRoute.usesPlayerLayer == route.usesPlayerLayer
        return Button(action: withHaptic { onSetPiPEngineRoute(route) }) {
            Text(title)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(selected ? Color.white : Color.primary)
                .frame(maxWidth: .infinity, minHeight: 38)
                .background(
                    selected ? Color.blue : Color.primary.opacity(0.055),
                    in: RoundedRectangle(cornerRadius: 12, style: .continuous)
                )
        }
        .buttonStyle(SpeedPressButtonStyle())
        .disabled(presentationState.activity == .starting || presentationState.activity == .stopping)
    }

    private func settingButton(
        title: String,
        value: String,
        systemName: String,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: withHaptic(action)) {
            HStack(spacing: 13) {
                Image(systemName: systemName)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(Color.blue)
                    .frame(width: 34, height: 34)
                    .background(Color.blue.opacity(0.11), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                Text(title)
                    .font(.body.weight(.medium))
                    .foregroundStyle(.primary)
                Spacer()
                Text(value)
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(.secondary)
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.tertiary)
            }
            .frame(minHeight: 56)
        }
        .buttonStyle(.plain)
    }

    private func iconButton(
        systemName: String,
        accessibilityLabel: String,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: withHaptic(action)) {
            Image(systemName: systemName)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.primary)
                .frame(width: 44, height: 44)
                .background(SpeedGlassCircleSurface())
        }
        .buttonStyle(SpeedPressButtonStyle())
        .accessibilityLabel(accessibilityLabel)
    }

    private var cacheCleanupButton: some View {
        Button(action: withHaptic(onClearCache)) {
            ZStack {
                Image(systemName: "trash.fill")
                    .font(.system(size: 15, weight: .semibold))
                Image(systemName: "sparkles")
                    .font(.system(size: 8, weight: .bold))
                    .offset(x: 8, y: -8)
            }
            .foregroundStyle(.primary)
            .frame(width: 44, height: 44)
            .background(SpeedGlassCircleSurface())
        }
        .buttonStyle(SpeedPressButtonStyle())
        .accessibilityLabel(L10n.text("清理缓存", "Clear cache"))
    }

    private var divider: some View {
        Divider().padding(.leading, 47)
    }

    private var localizedStatusTitle: String {
        switch presentationState.activity {
        case .ready: return L10n.text("已就绪", "Ready")
        case .starting: return L10n.text("正在启动", "Starting")
        case .running, .hidden: return L10n.text("120Hz 已启动", "120 Hz started")
        case .stopping: return L10n.text("正在关闭", "Stopping")
        case .failed: return L10n.text("需要重新尝试", "Try again")
        }
    }

    private var primaryActionTitle: String {
        switch presentationState.activity {
        case .starting:
            return L10n.text("正在启动", "Starting")
        case .stopping:
            return L10n.text("正在关闭", "Stopping")
        case .running, .hidden:
            return L10n.text("关闭 Speed", "Stop Speed")
        case .ready, .failed:
            return L10n.text("启动悬浮窗", "Start PiP")
        }
    }

    private func withHaptic(_ action: @escaping () -> Void) -> () -> Void {
        {
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
            action()
        }
    }
}

private struct SpeedBackground: View {
    var body: some View {
        ZStack {
            Color(UIColor.systemGroupedBackground)
            LinearGradient(
                colors: [Color.cyan.opacity(0.22), Color.blue.opacity(0.10), .clear],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
}

private struct SpeedGlassCard<Content: View>: View {
    private let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        content
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(SpeedGlassSurface(cornerRadius: 24, castsShadow: true))
    }
}

/// One glass recipe for cards and actions so adjacent controls never look like
/// unrelated opaque panels.
private struct SpeedGlassSurface: View {
    let cornerRadius: CGFloat
    var isInteractive = false
    var castsShadow = false

    @ViewBuilder
    var body: some View {
        let shape = RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
        if #available(iOS 26.0, *) {
            if isInteractive {
                liquidGlass(shape: shape, interactive: true)
            } else {
                liquidGlass(shape: shape, interactive: false)
            }
        } else {
            shape
                .fill(.regularMaterial)
                .overlay { shape.stroke(.primary.opacity(0.075), lineWidth: 0.5) }
        }
    }

    @ViewBuilder
    private func liquidGlass(shape: RoundedRectangle, interactive: Bool) -> some View {
        let surface = shape
            .fill(Color.white.opacity(0.045))
            .glassEffect(interactive ? .regular.interactive() : .regular, in: shape)
            .overlay { shape.stroke(.white.opacity(0.28), lineWidth: 0.8) }
        if castsShadow {
            surface.shadow(color: .cyan.opacity(0.10), radius: 18, y: 8)
        } else {
            surface
        }
    }
}

private struct SpeedGlassCircleSurface: View {
    var body: some View {
        let shape = Circle()
        if #available(iOS 26.0, *) {
            shape
                .fill(Color.white.opacity(0.035))
                .glassEffect(.regular.interactive(), in: shape)
                .overlay { shape.stroke(.white.opacity(0.24), lineWidth: 0.7) }
        } else {
            shape
                .fill(.regularMaterial)
                .overlay { shape.stroke(.primary.opacity(0.07), lineWidth: 0.5) }
        }
    }
}

private struct SpeedPressButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.985 : 1)
            .opacity(configuration.isPressed ? 0.88 : 1)
            .animation(.easeOut(duration: 0.12), value: configuration.isPressed)
    }
}

//
//  AppDesignSystem.swift
//  pip_swift
//
//  Speed visual foundation for iOS 26/27.
//  Keep visual constants centralized so the UI feels like one product rather
//  than a collection of independently styled screens.
//

import UIKit

enum AppDesignSystem {
    enum Spacing {
        static let xSmall: CGFloat = 4
        static let small: CGFloat = 8
        static let medium: CGFloat = 12
        static let regular: CGFloat = 16
        static let large: CGFloat = 20
        static let xLarge: CGFloat = 24
        static let section: CGFloat = 32
    }

    enum Radius {
        static let control: CGFloat = 14
        static let card: CGFloat = 20
        static let hero: CGFloat = 28
    }

    enum Typography {
        static func heroNumber() -> UIFont {
            scaledSystemFont(size: 52, weight: .semibold, design: .rounded)
        }

        static func title() -> UIFont {
            scaledSystemFont(size: 28, weight: .semibold)
        }

        static func sectionTitle() -> UIFont {
            scaledSystemFont(size: 17, weight: .semibold)
        }

        static func body() -> UIFont {
            UIFont.preferredFont(forTextStyle: .body)
        }

        static func secondary() -> UIFont {
            UIFont.preferredFont(forTextStyle: .subheadline)
        }

        static func caption() -> UIFont {
            UIFont.preferredFont(forTextStyle: .caption1)
        }

        private static func scaledSystemFont(
            size: CGFloat,
            weight: UIFont.Weight,
            design: UIFontDescriptor.SystemDesign = .default
        ) -> UIFont {
            let base = UIFont.systemFont(ofSize: size, weight: weight)
            let descriptor = base.fontDescriptor.withDesign(design) ?? base.fontDescriptor
            return UIFontMetrics.default.scaledFont(for: UIFont(descriptor: descriptor, size: size))
        }
    }

    enum Layout {
        /// Comfortable readable width on an iPhone while still allowing edge-to-edge glass.
        static let horizontalContentInset: CGFloat = 18
        static let minimumTouchDimension: CGFloat = 44
    }
}

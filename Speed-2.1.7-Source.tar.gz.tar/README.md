# Speed

Speed is a focused iPhone Picture-in-Picture utility for keeping a responsive
high-refresh presentation path on supported ProMotion devices.

## What is included

- One fast, single-screen control surface.
- Start, stop, compact PiP, appearance, size, and engine-mode controls.
- A fixed 120 Hz display request plus a compositor-side PiP surface driver for
  stable high-refresh signaling after switching to another app.
- Static PiP text with no per-frame Swift layout work; the low-power route does
  not decode the silent-audio asset unless an audio keep-alive mode needs it.
- No update checker, network-speed sampler, frame-rate demo, shortcut bridge,
  Control Center extension, or user tracking.
- An Apple-style Speed app icon and automatic-signing-ready project settings.

## Build an unsigned IPA

Run `./scripts/build_unsigned_ipa.sh` on macOS with Xcode 26 or later. The IPA
is written to `dist/Speed-unsigned.ipa`; sign it using your preferred personal
signing workflow before installing.

The project requires iOS 26 or later. Keep the included `NOTICE` when copying
or redistributing this derivative source tree.

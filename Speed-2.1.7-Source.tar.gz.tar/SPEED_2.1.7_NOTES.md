# Speed 2.1.7 performance checkpoint

This build intentionally avoids adding any hidden or synthetic refresh animation.

## Core changes
- Keeps one production hard-max `CADisplayLink` with an empty callback for the standard VideoCall route.
- Forces obsolete scrolling/clock content drivers off so stale preferences cannot create a second persistent display link.
- Uses `CADisplayLink.targetTimestamp` for the short PiP height transition.
- Deduplicates PiP size submissions at physical-pixel granularity before touching AVKit geometry.
- Restricts the generic UIKit background task to PiP start transitions and ends it once AVKit confirms or the transition fails.
- Moves refresh-rate lifecycle ownership directly to `SceneDelegate` and removes the obsolete root wrapper controller.
- Makes heavy diagnostic startup DEBUG-only; Release cannot enable the debug logger at runtime.
- Groups adjacent Liquid Glass controls with `GlassEffectContainer` and keeps expensive shadows on cards rather than every interactive control.

## Intentionally unchanged
- 120 Hz hard-max request policy (`minimum == maximum == preferred`).
- VideoCall remains the standard route; PlayerLayer remains compatibility mode.
- No transparent blinking, sub-pixel movement, 120 Hz timers, network polling, or continuous invisible PiP content animation was added.

# GlobalRefresh X — Alpha 24

## Focus
Global 120Hz runtime cleanliness and frame-pacing audit.

## Changes
- Removed the dormant `fpsProbeDisplayLink` ownership and `updateFPSProbe` callback from the PiP runtime.
- Simplified clock teardown so only actually-owned clock render drivers are invalidated.
- Added verification rule 13 to prevent the redundant FPS probe from returning to the release-critical ViewController path.
- Preserved the global-refresh mechanism: VideoCall PiP route, strict frame-rate request, 0.1pt geometry, and PlayerLayer compatibility behavior are unchanged.

## Product rule
GlobalRefresh X is optimized for the experience outside this app: while its PiP-based mechanism is active, the objective is system-wide high-refresh scheduling for other apps and system UI. The app UI must remain lightweight so it does not steal main-thread/CPU/GPU budget from that objective. Public iOS APIs still make frame-rate requests best-effort; real global frame pacing must be validated on-device.

## Version
- 2.0.0-alpha24
- build 2026090524

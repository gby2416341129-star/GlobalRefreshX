# GlobalRefresh X — Alpha 7 进度

Alpha 7 继续围绕 iOS 26/27 与 iPhone 17 Air 做核心架构收敛，重点不是增加表面功能，而是减少 PiP 状态冲突和私有兼容代码扩散。

## 本轮完成

- 新增 `PiPTransitionCoordinator.swift`，把 PiP 启动/停止事务的时间、原因、期望状态和序列号收口为单一状态源。
- `ViewController` 不再直接写入 `isPiPTransitioning / pipTransitionStartedAt / pipTransitionReason / pipTransitionExpectedActive` 四套可互相矛盾的状态；改为只从事务协调器读取。
- 新增 `PiPCompatibilityAdapter.swift`，把两处没有公开替代 API 的行为集中隔离：PiP `controlsStyle` KVC 与 `UIApplication suspend` 兼容动作。
- 删除已永远关闭的 iOS 15 `controlsStyle=2 -> 1` 实验与回退代码，避免 iOS 26/27 项目继续携带无效历史状态。
- 兼容层失败时改为安全返回，不让主 PiP Engine 直接依赖私有 selector。
- 新增文件已加入 Xcode target 的 Sources Build Phase。
- 使用 Swift frontend 对本轮新文件和 `ViewController.swift` 做语法解析验证，通过。
- App 版本更新为 `2.0.0-alpha7 (2026090507)`。

## 设计原则

- 公开 Apple API 是主路径；未公开但当前功能仍依赖的行为只能存在于单独兼容层，后续可在 iOS 26/27 真机测试后整体关闭或替换。
- 不在同一轮同时改刷新率策略、PiP Geometry 与播放器保活，避免出现回归时无法定位来源。
- iPhone 17 Air 为第一优先设备，旧系统兼容不再是设计目标。

## 下一步

1. 继续删除 `needsLegacyPiPCompatibility = false` 之后已经永远不可达的旧低版本分支。
2. 把 start / stop / retry / timeout 的重试策略从 `ViewController` 向 PiP Engine/事务协调器迁移。
3. 对 `CADisplayLink`、Timer、通知观察器做一次全量拥有关系审计，避免重复唤醒与遗留计时器。
4. 在 GitHub macOS runner 上进行第一次真实 Xcode Release 编译，优先修复编译/API 问题，再进入 Liquid Glass UI 重构。

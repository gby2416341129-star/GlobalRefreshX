# GlobalRefresh X — Alpha 27

## Focus
120 Hz hot-path audit: disabled diagnostics must be effectively free.

## Changes
- Audited the VideoCall/clock display-link callback path.
- `logBackgroundClockDiagnosticsIfNeeded` now exits immediately when debug mode is disabled, before PiP suspension reads, application-state work, FPS math, timestamp bookkeeping, or log interpolation.
- Preserved the actual refresh-rate request, VideoCall route, PlayerLayer compatibility activity driver, 0.1pt behavior, and PiP lifecycle timings.
- Added verification rule 17 so the hot-path diagnostics gate cannot be accidentally removed later.

## Validation
- Project verification: 17/17 passed.
- Swift frontend syntax parse: covered by verification.
- Info.plist lint: passed by verification.

## Version
- 2.0.0-alpha27
- Build 2026090527

## Important limitation
Static audit cannot prove system-wide 120 Hz frame pacing. Xcode Release compilation and iPhone 17 Air device measurements remain required.

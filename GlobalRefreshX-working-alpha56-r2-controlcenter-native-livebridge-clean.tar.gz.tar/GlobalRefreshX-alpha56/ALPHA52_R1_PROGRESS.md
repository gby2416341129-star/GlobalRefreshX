# Alpha52-r1 Control Center Runtime Truth

Version: 2.0.0-alpha52-r1  
Build: 2026090755

- Control Center tile deliberately reduced to two user-facing states: `工作中` / `未工作`.
- Runtime state remains authoritative: ON is written only after PiP actually starts; OFF is written when PiP stops.
- Heartbeat changed from wall-clock `Date` to monotonic `systemUptime`, avoiding false state after manual clock changes. A reboot automatically invalidates the previous lease.
- App Group access is now fail-closed. The host and extension never fall back to separate `.standard` stores, preventing a false green/running indication when signing misses the shared entitlement.
- 20-second heartbeat remains outside the 120 Hz display-link hot path. The control considers a lease stale after 45 seconds when WidgetKit next reloads/renders the control.
- No private API, fake VPN, or unsupported background entitlement was added.

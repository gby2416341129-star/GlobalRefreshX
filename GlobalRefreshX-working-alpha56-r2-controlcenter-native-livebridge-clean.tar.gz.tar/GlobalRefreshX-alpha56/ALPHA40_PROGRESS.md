# Alpha 40 Progress

- Audited the primary iOS asset catalog against the iPhone-only target policy.
- Removed stale iPad AppIcon declarations and PNGs from the shipping Swift target.
- Kept the existing iPhone, App Store, dark, and tinted icon assets unchanged.
- Added verifier rule 31 to ensure AppIcon is selected, required iPhone/App Store slots exist, referenced icon files exist, and iPad icon declarations do not regress.
- Core PiP, 0.1pt VideoCall route, high-refresh driver, and PlayerLayer compatibility behavior are unchanged.
- Version: 2.0.0-alpha40 (2026090640).

# GlobalRefresh X — Alpha 15

## 本轮重点：正式开始新版中文首页视觉骨架

- 将 Alpha 14 的 `HomePresentationState` 真正接入 `PiPHomeView`，首页开始由统一状态快照驱动，而不是再新增一套 UI 状态真相源。
- 新增首页 120Hz Hero 状态卡：大号刷新率、运行状态、标准/兼容模式、PiP 高度和刷新请求状态集中呈现。
- Hero 使用系统 Material、连续圆角和极轻描边建立层级；不使用持续动画模糊、不增加 CADisplayLink，不让视觉效果干扰刷新率核心机制。
- 数字变化使用 SwiftUI `contentTransition(.numericText())`，只处理离散状态变化，不创建逐帧自定义动画。
- 增加 VoiceOver 合并语义，避免漂亮 UI 牺牲可访问性。
- 保留原版 UI 的深色/卡片/专业工具基因，但开始减少“设置面板堆叠感”，让核心状态成为首页第一视觉层级。

## 审查

- `scripts/verify_project.sh` 全量通过。
- Info.plist 校验通过。
- iOS 26+ / iPhone-only 策略通过。
- 全 Swift 语法解析通过。
- Xcode 工程核心文件引用检查通过。
- Merge conflict marker 检查通过。

## 版本

- `2.0.0-alpha15`
- Build `2026090515`

## 下一轮

继续重构首页信息层级和主操作区，减少旧版首页的次要操作噪声；同时审计 SwiftUI 动画、Material/blur 和布局热点，优先保证 120Hz 帧预算和可中断交互。

# GlobalRefresh X — Alpha 22

- Audited keep-alive delayed callbacks for stale-callback / perceived-latency risk.
- Replaced the two raw `DispatchWorkItem` owners in `KeepAliveLogger` (background probe safety-window resume and unlock resume) with `DelayedTaskScheduler` slots.
- Cancellation/replacement semantics are now centralized and consistent with PiP and shortcut scheduling.
- Preserved existing delays and keep-alive behavior; no change to 120Hz request, PiP routes, or 0.1pt geometry.
- Added CI invariant rejecting raw `DispatchWorkItem` ownership in `KeepAliveLogger`.
- Version: 2.0.0-alpha22 (2026090522).

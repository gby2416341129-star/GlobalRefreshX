# GlobalRefresh X — Alpha 16

## Focus
Home interaction correctness and native-feeling state behavior.

## Changes
- Made the home primary control derive its title, symbol and enabled state from `HomePresentationState` instead of scattered booleans.
- Fixed the primary control symbol so an active PiP now presents `pip.exit` instead of always showing the enter symbol.
- Prevented primary/start-and-hide actions from accepting taps while PiP is already starting or stopping, reducing duplicate transition requests and UI/core state races.
- Moved the 0.1 pt / 1 pt action label into the immutable home presentation snapshot.
- Added activity-specific hero symbols for ready, starting, running, hidden, stopping and failed states.
- Removed the redundant local `startAndHidePiPButtonTitle` presentation branch.

## Review intent
This round is deliberately small and state-oriented: visual polish is not useful if controls can dispatch duplicate lifecycle operations. The home UI should behave like a native system surface under rapid interaction, not merely look polished.

## Validation
Run `scripts/verify_project.sh` after every material change. A macOS/Xcode Release build and device validation are still required before considering the build production-safe.

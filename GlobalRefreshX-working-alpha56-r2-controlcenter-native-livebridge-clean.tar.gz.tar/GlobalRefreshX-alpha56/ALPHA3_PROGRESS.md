# GlobalRefresh X — Alpha 3 progress

- Added `PiPLifecycleController`, a dedicated PiP lifecycle state machine.
- Hooked AVPictureInPictureController delegate callbacks into the lifecycle state machine.
- Lifecycle transitions are now logged with sequence numbers, making stale/duplicate transitions easier to diagnose.
- Kept existing PiP implementation intact to avoid changing the proven 120 Hz behavior while refactoring.
- Next extraction target: PiP engine ownership (VideoCall vs PlayerLayer) and 0.1 pt geometry.

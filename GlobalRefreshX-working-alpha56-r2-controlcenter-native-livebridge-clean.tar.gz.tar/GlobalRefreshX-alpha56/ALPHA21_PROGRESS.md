# GlobalRefresh X — Alpha 21

Version: 2.0.0-alpha21  
Build: 2026090521

## Focus
Shortcut delayed-work ownership and stale-callback prevention.

## Changes
- Added `DelayedTaskScheduler<Slot>` as a reusable single-owner scheduler for replaceable delayed work.
- Refactored `PiPTaskScheduler` to delegate storage/cancellation semantics to the shared scheduler without changing its public behavior.
- Removed raw `[DispatchWorkItem]` ownership from `MainTabBarController` shortcut retries.
- Shortcut retry attempts now use explicit keyed slots; newer scheduling cancels the previous generation via `cancelAll()`.
- Shortcut-disabled alert retry now has a replaceable dedicated slot instead of an unmanaged `asyncAfter` callback.
- `MainTabBarController.deinit` explicitly cancels outstanding shortcut tasks.
- Added CI verification rule preventing raw `DispatchWorkItem` ownership from returning to `MainTabBarController`.
- Added the shared scheduler to the Xcode project Sources phase.

## Review notes
- Retry delays and shortcut behavior are intentionally unchanged.
- 120 Hz request logic, VideoCall/PlayerLayer routes, PiP geometry and 0.1 pt behavior are unchanged.
- This is an ownership/lifecycle hardening change intended to reduce stale delayed callbacks during rapid foreground/shortcut transitions.

## Verification
- Project verification: 10/10 passed.
- All Swift files frontend-parsed successfully in the current environment.
- Full UIKit/AVKit typecheck and Release compilation still require Xcode/macOS CI.

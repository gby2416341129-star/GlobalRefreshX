# Alpha54 — Control Center Fresh Kind / Runtime Truth

- Bumped the Control Widget kind to `com.yoroin.globalrefresh.control.runtime.v2` to force iOS to create a fresh Control configuration instead of reusing the cached Alpha52/53 template.
- Uses the current `ControlWidgetToggle(isOn:action:label:valueLabel:)` API with explicit label and value label.
- Runtime state remains fail-closed and requires the shared App Group entitlement in the final signed host app and extension.
- 120 Hz hot path is unchanged.
- Force-quitting the host app still terminates the PiP-backed refresh session; public iOS APIs do not provide a supported way to hide/kill the app scene while keeping this PiP/CADisplayLink runtime alive.

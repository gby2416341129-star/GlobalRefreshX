# Alpha 36 Progress

- Added an explicit iPhoneOS SDK preflight to the unsigned-IPA build pipeline.
- The build now requires the selected Xcode to expose iPhoneOS SDK 26 or newer before CocoaPods or compilation starts.
- Prints the selected Xcode and iPhoneOS SDK version into CI logs for reproducibility.
- Added verification rule 27 to prevent accidental removal of the SDK gate.
- Core PiP and refresh-rate behavior is unchanged.

Validation scope: static project verification and Swift parser checks only; this is not an Xcode/iOS SDK build result.

# GlobalRefresh X worklog

## 2026-09-05 — implementation started
- Preserved the original VideoCall PiP / PlayerLayer dual-engine source as the functional baseline.
- Added a reproducible macOS/Xcode cloud build pipeline that emits a real iPhone `.ipa` container from the Release iPhoneOS build.
- Added `scripts/build_unsigned_ipa.sh` for deterministic Release builds with code signing disabled, so the resulting IPA can be signed by the user's existing signing method without needing a local Mac.
- Added GitHub Actions workflow `.github/workflows/build-ipa.yml` using a macOS runner.
- Removed stale `armv7` required-device capability from the iOS 15+ target.
- Renamed the development branch display name to `GlobalRefresh X` and bumped the development version to `2.0.0-alpha1`.

## Next implementation pass
1. Isolate refresh-rate scheduling from `ViewController` and eliminate duplicate display-link wakeups.
2. Isolate PiP lifecycle/engine switching and harden start/stop/recovery state transitions.
3. Make VideoCall + 0.1pt the primary path and PlayerLayer the explicit compatibility path.
4. Rebuild the home UI around one primary start/stop action, current engine/status, 0.1pt action, and low-power status.
5. Keep diagnostics available but move them out of the primary UI.

## Alpha 7
- 引入 PiPTransitionCoordinator，统一启动/停止事务状态。
- 引入 PiPCompatibilityAdapter，隔离非公开兼容行为。
- 删除永远关闭的 iOS 15 controlsStyle 实验回退。
- Swift frontend 语法解析验证通过。

## Alpha 9 — 2026-09-05
- 新增 `PiPTaskScheduler`，统一拥有 PiP 启动重试、启动超时和 transition watchdog。
- 同类任务重新调度时自动取消旧任务，执行后自动从 registry 移除。
- 销毁、失败恢复、系统停止路径统一取消核心 PiP 延迟任务。
- 保持 Refresh / Geometry / PiP route 行为不变。


## Alpha 10
- Unified four additional delayed PiP task classes under PiPTaskScheduler.
- Removed corresponding ViewController DispatchWorkItem ownership fields.
- Corrected Info.plist version metadata to alpha10.


## Alpha 11
清理 iOS 26+ 永不执行的 VideoCall 低版本兼容分支，减少 PiP 核心状态复杂度；保留 PlayerLayer 实际兼容路线。

## 2026-09-05 — Alpha 18
- Audited appearance-change frame-time path.
- Removed unreachable pre-iOS-26 branch.
- Migrated appearance fade to AppMotion/UIViewPropertyAnimator.
- Removed recursive synchronous full-view-hierarchy redraw and delayed second redraw.
- Added Reduce Motion behavior and strengthened project verifier.

## Alpha 19
- Centralized remaining ViewController delayed PiP work under PiPTaskScheduler.
- Added CI guardrails for unmanaged UIView.animate and raw ViewController DispatchWorkItem ownership.

## Alpha 21 — 2026-09-05
- Introduced reusable DelayedTaskScheduler.
- Migrated MainTabBarController shortcut retry/alert delayed work away from raw DispatchWorkItem ownership.
- PiPTaskScheduler now reuses the same scheduler primitive.
- Verification expanded to 10 checks and passed.

## 2026-09-05 — Alpha 25
- Audited disabled diagnostics cost on 120 Hz runtime paths.
- Made AppDebugLogger messages lazy via @autoclosure so interpolation is skipped when Debug is off.
- Removed stale FPS probe timestamp state.
- Verification expanded to 14 checks; all passed.

## Alpha 29
- Build-chain audit found Podfile still targeting iOS 15 despite the app policy being iOS 26+; corrected to iOS 26.
- Build script now enforces project verification before dependency installation/Xcode compilation.
- Deterministic Release `.app` lookup replaces first-match packaging.
- Verification expanded to 20 checks; all passed locally.

- Alpha 42: added PBX build-phase graph integrity validation and moved success banner after all checks.

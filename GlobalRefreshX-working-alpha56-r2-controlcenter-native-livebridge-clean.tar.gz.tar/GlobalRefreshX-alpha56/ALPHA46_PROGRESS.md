# GlobalRefresh X — Alpha 46

## Xcode 26.6 compile fix

- Fixed the first real Xcode build blocker found by GitHub Actions run #4.
- `AVPictureInPictureController(playerLayer:)` is failable under the iOS 26 SDK and therefore returns an optional controller.
- PlayerLayer construction now uses `guard let` and reports a dedicated engine error instead of treating the optional as non-optional.
- Core VideoCall/0.1pt/high-refresh behavior is unchanged.
- Version: 2.0.0-alpha46 (2026090646).

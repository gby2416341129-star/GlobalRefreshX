# GlobalRefresh X Alpha55 — Control Center Rebuild

- Version: 2.0.0-alpha55 (2026090859)
- Control kind v3 to force a fresh system registration.
- Rebuilt ControlWidgetToggle to match Apple’s documented template exactly.
- Native leading SF Symbol: bolt.horizontal.circle(.fill).
- Runtime truth no longer depends on App Group/UserDefaults.
- ControlValueProvider queries the live host process using Darwin notifications.
- No host response means 未运行, so a killed host cannot report a stale running state.
- Start/stop use separate Darwin command notifications, so no payload/shared-container dependency.
- Start intent can request a foreground transition, then replays the start command after scene registration.
- Host answers live runtime queries from the SceneDelegate bridge.
- PiP delegate remains the authority that marks runtime running/stopped.
- 120 Hz CADisplayLink hot path is unchanged.

# Alpha 32 Progress

- Removed the final three `preferredFramesPerSecond` uses from the iOS 26+ app target.
- PlayerLayer activity driver now expresses its intentional 30 Hz cadence with `CAFrameRateRange(30/30/30)`.
- Launch celebration and frame-rate test surfaces no longer retain unreachable iOS 15 fallback branches.
- Added verification rule rejecting deprecated `preferredFramesPerSecond` in app Swift sources.
- Core VideoCall PiP / 0.1 pt / global high-refresh behavior is unchanged.

Validation: 24/24 project verification checks, Swift parser pass, plist lint.

# Alpha53 — Control Runtime Truth

- Control Center UI now explicitly renders `运行中` / `未运行` with a stable bolt glyph.
- Added `controlWidgetStatus` for native iOS 26/27 status presentation.
- Host and extension now validate that the App Group container is actually accessible before reading/writing runtime truth.
- No fallback to per-process UserDefaults: missing signing entitlement fails closed as `未运行`.
- Runtime truth remains PiP-confirmed and heartbeat-backed; no work added to the 120 Hz CADisplayLink callback.
- Version: 2.0.0-alpha53 (2026090756).

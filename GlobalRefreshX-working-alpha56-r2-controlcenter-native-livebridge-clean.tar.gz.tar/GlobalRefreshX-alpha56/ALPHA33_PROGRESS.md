# Alpha 33 Progress

- Migrated three stale-prone delayed UIKit/PiP callbacks from raw `DispatchQueue.main.asyncAfter` to `PiPTaskScheduler`.
- Added dedicated cancellable slots for launch notification presentation, engine-route transition settling, and foreground-window restoration.
- These jobs are now owned by the controller lifecycle and are cancelled by the existing `pipTasks.cancelAll()` cleanup path.
- No change to the VideoCall 0.1pt PiP refresh request or PlayerLayer compatibility cadence.
- Version: 2.0.0-alpha33 (2026090533).

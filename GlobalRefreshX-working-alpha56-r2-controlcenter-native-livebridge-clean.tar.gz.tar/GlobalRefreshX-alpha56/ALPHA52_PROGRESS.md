# GlobalRefresh X Alpha52 — Control Center / Zero-Jitter Experiment

Version: 2.0.0-alpha52  
Build: 2026090754

## What changed

- Added a real WidgetKit `ControlWidgetToggle` for iOS Control Center / Lock Screen / Action Button system spaces.
- The control intentionally shows only `运行中` / `未运行` and a simple bolt state.
- Added a shared App Group runtime-state channel so the control can reflect the PiP runtime instead of a cosmetic toggle value.
- Added a low-frequency 20 s heartbeat with a 48 s stale timeout. It is completely isolated from the 120 Hz CADisplayLink hot path.
- PiP delegate `didStart` / `didStop` are the authoritative state transitions.
- Added a Darwin-notification command bridge so an already-alive app can receive Control Center start/stop commands without polling.
- When the process/UI scene is absent and a start needs PiP preparation, the App Intent uses the current `supportedModes` / `continueInForeground` API instead of deprecated `openAppWhenRun`.
- Existing hard maximum-refresh policy is unchanged: one CADisplayLink, min=max=preferred=target, empty per-frame callback.

## Important platform boundary

A third-party iOS app cannot publicly make a normal UIKit scene disappear from the App Switcher while keeping arbitrary app code alive like a Network Extension. Alpha52 tests the closest public architecture: system Control + minimal shared state + PiP runtime. Starting from a killed state may still require iOS to foreground the app so PiP can establish its UIKit source scene. Once running, stop/status commands can be handled without reopening the main UI when the process remains alive.

## Signing note

The Control Center extension and host app use App Group `group.com.yoroin.globalrefresh.shared`. The final signer/provisioning setup must preserve that entitlement for host + extension; otherwise the shared status channel cannot work correctly.

## Verification

- Swift parse checks for new control/runtime bridge: PASS
- Project static verifier: 39/39 PASS
- Plist / entitlement lint: PASS
- Real Xcode 26 build: pending GitHub Actions
- Device Control Center behavior: pending device A/B test

import AppIntents
import Foundation
import WidgetKit

/// Runtime truth bridge for the iOS Control Center control.
///
/// The widget asks the live host over Darwin notifications. No response means
/// "not running". Commands are also duplicated as an AppIntent in the host
/// target so iOS can foreground the actual app when a suspended host must be
/// resumed before PiP can be started or stopped.
enum ControlCenterRuntimeState {
    static let controlKind = "com.yoroin.globalrefresh.control.runtime.v4"

    static let startCommandNotification = "com.yoroin.globalrefresh.control.v4.start"
    static let stopCommandNotification = "com.yoroin.globalrefresh.control.v4.stop"
    static let queryNotification = "com.yoroin.globalrefresh.control.v4.query"
    static let runningResponseNotification = "com.yoroin.globalrefresh.control.v4.running"
    static let stoppedResponseNotification = "com.yoroin.globalrefresh.control.v4.stopped"

    private static let stateQueue = DispatchQueue(label: "com.yoroin.globalrefresh.control-runtime-state")
    private static var runtimeRunning = false

    static var isRuntimeRunning: Bool {
        stateQueue.sync { runtimeRunning }
    }

    static func markRunning() {
        stateQueue.sync { runtimeRunning = true }
        reloadControl()
    }

    static func markStopped() {
        stateQueue.sync { runtimeRunning = false }
        reloadControl()
    }

    static func respondToRuntimeQuery() {
        postDarwin(isRuntimeRunning ? runningResponseNotification : stoppedResponseNotification)
    }

    static func postDarwin(_ name: String) {
        CFNotificationCenterPostNotification(
            CFNotificationCenterGetDarwinNotifyCenter(),
            CFNotificationName(name as CFString),
            nil,
            nil,
            true
        )
    }

    private static func reloadControl() {
        Task { @MainActor in
            ControlCenter.shared.reloadControls(ofKind: controlKind)
        }
    }
}

/// Host-side metadata copy of the Control Center intent. Keeping the intent in
/// the app target as well as the widget target lets App Intents route a required
/// foreground transition to the actual UIKit host instead of leaving the action
/// trapped inside the extension process.
struct SetGlobalRefreshRunningIntent: SetValueIntent {
    static let title: LocalizedStringResource = "GlobalRefresh X"
    static let description = IntentDescription("启动或停止 GlobalRefresh X 高刷核心。")
    static let supportedModes: IntentModes = [.background, .foreground(.dynamic)]

    @Parameter(title: "运行中")
    var value: Bool

    func perform() async throws -> some IntentResult {
        ControlCenterRuntimeState.postDarwin(
            value
                ? ControlCenterRuntimeState.startCommandNotification
                : ControlCenterRuntimeState.stopCommandNotification
        )
        return .result()
    }
}

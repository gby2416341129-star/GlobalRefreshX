# Alpha 50 — Lean 120 / Maximum Stability

- Version: 2.0.0-alpha50; build: 2026090752.
- Restores and preserves the hard maximum-refresh request: min=max=preferred=120 on supported 120 Hz devices.
- Keeps exactly one app-level VideoCall-route CADisplayLink with an intentionally empty per-frame callback.
- Caches the configured target to avoid redundant frame-rate preference writes.
- Resolves the active UIWindowScene screen maximum first, with launch-time UIScreen fallback.
- Suspends optional debug diagnostic timers/display links while the app is backgrounded, leaving the PiP + hard-max refresh path as lean as possible.
- Does not add UIUpdateLink immediate-presentation or duplicate display links because those cannot reduce latency in other foreground apps and may increase hitch risk.
- Removes legacy non-target source trees from the clean distribution after verification; this reduces source/package clutter but does not claim runtime FPS gains.

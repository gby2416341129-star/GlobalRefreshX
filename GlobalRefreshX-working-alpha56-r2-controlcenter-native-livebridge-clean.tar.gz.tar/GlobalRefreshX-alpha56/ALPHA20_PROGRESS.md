# GlobalRefresh X — Alpha 20

## 本轮重点：Release 正常路径诊断零侵入

- 审计 `AppDebugLogger` / `DebugDiagnosticsMonitor` 的 DisplayLink、Timer 与生命周期观察者启动路径。
- 修复一个真实的性能边界问题：单独的诊断开关可能在主 Debug 开关关闭后残留，后续 `startIfNeeded()` 仍可能重新拉起帧监控 DisplayLink / 性能计时器。
- `DebugDiagnosticsMonitor.startIfNeeded()` 现在以 `AppDebugLogger.isDebugModeEnabled` 作为主门控；主调试关闭时主动 `stop()`，不允许陈旧子开关复活诊断任务。
- `AppDebugLogger.registerBackgroundFlush()` 在调试关闭时不注册后台/终止 NotificationCenter observers，减少正式正常使用路径的无意义观察者和唤醒。
- 验证脚本扩展到 9 项，新增诊断主门控回归检查。
- 未修改 120Hz 请求、PiP VideoCall/PlayerLayer、0.1pt 几何与核心启动/停止时序。

版本：2.0.0-alpha20 (2026090520)

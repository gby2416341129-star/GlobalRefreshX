# Alpha 31 Progress

- Version: `2.0.0-alpha31` (`2026090531`).
- Audited the app-level global refresh driver against the user-facing high-refresh switch.
- Fixed a real runtime-policy inconsistency: disabling high refresh previously left `RefreshRateController` alive and pinned its range to 80 Hz (`minimum = maximum = preferred = 80`). The controller now fully invalidates its display link whenever `FrameRatePreference.isHighRefreshEnabled` is false.
- This makes the disabled state truly system-adaptive, removes an unnecessary main-run-loop callback source, and prevents the app from continuing to influence refresh scheduling after the feature is explicitly turned off.
- The enabled path remains unchanged: VideoCall route continues to request the selected high-refresh target with the strict `CAFrameRateRange` configuration; PlayerLayer/extreme-silent policies remain unchanged.
- Added verification gate 23 so this disabled-state behavior cannot silently regress.
- Re-ran project verification, Swift parser checks, and plist lint.

Important: static verification is not a substitute for an Xcode SDK type-check or iPhone 17 Air frame-pacing test.

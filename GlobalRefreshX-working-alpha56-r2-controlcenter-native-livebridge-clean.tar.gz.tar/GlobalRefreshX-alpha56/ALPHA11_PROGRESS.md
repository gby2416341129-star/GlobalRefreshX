# Alpha 11 进度

本轮目标：继续清理 iOS 26/27-only 架构中的历史兼容死代码，降低核心 PiP 启停路径的分支复杂度。

## 已完成
- 删除恒为 false 的 `needsLegacyPiPCompatibility` 历史低版本开关。
- 删除 `didRetryLegacyPiPStart` 与整套低版本 VideoCall fallback 重试逻辑。
- VideoCall 路线启动重试固定为现代 iOS 26+ 策略：首次 0.02s，后续 0.12s，最多 8 次。
- PlayerLayer 兼容路线仍保留独立的 36 次准备重试与启动确认机制，避免影响现有兼容效果。
- 简化关闭 PiP 时的 offscreen geometry、前台恢复与 willStop 状态分支。
- 保持 RefreshRateController、0.1pt Geometry、VideoCall/PlayerLayer 核心工作原理不变。
- Swift 语法解析通过，Info.plist 校验通过。

## 版本
- 2.0.0-alpha11
- Build 2026090511

## 下一步
- 继续把 PiP start/stop orchestration 从 ViewController 收入独立协调器。
- 为最终中文 Liquid Glass UI 建立统一 Design Tokens 与状态模型，避免 UI 与底层逻辑直接耦合。

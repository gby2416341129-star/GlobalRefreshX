# GlobalRefresh X — Alpha 18

## Focus
Main-thread frame-time audit for appearance transitions and UI animation hygiene.

## Changes
- Removed the now-unreachable pre-iOS-26 appearance compatibility branch. The app targets iOS 26+ only.
- Replaced the remaining appearance-transition `UIView.animate` path with the centralized interruptible `AppMotion` animator.
- Appearance switching now respects Reduce Motion by avoiding the snapshot animation entirely when requested by Accessibility.
- Removed recursive `layoutIfNeeded()` / `setNeedsDisplay()` traversal across the entire view hierarchy during appearance changes.
- Replaced it with root-level invalidation so UIKit/SwiftUI can coalesce layout/display work on the next render pass.
- Removed the second delayed full-hierarchy redraw. This avoids an avoidable main-thread spike ~180ms after a theme switch.
- Strengthened `verify_project.sh` so `HomePresentationState.swift` must remain referenced by the Xcode project.

## Why it matters
A recursive synchronous layout pass can consume a meaningful portion of an 8.33ms 120Hz frame budget, especially on a hierarchy containing SwiftUI hosting views and material effects. The new path keeps the transition compositing-friendly and interruption-safe while preserving the visual crossfade.

## Validation
- Full Swift syntax parse.
- Info.plist validation.
- iOS 26+ / iPhone-only policy validation.
- Core project reference validation.
- Merge-conflict marker scan.

This is still static/local validation. Real UIKit/AVKit type checking and device frame-time behavior require the upcoming Xcode CI build and iPhone 17 Air validation.

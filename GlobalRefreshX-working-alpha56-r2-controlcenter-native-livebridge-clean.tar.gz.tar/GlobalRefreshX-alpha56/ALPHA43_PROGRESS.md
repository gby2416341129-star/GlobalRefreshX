# GlobalRefresh X Alpha 43

- Version: 2.0.0-alpha43 (2026090643)
- Accelerated CI by making the checked-in CocoaPods snapshot the primary build path.
- `build_unsigned_ipa.sh` now skips CocoaPods/network work when `Pods/Manifest.lock` exactly matches `Podfile.lock`; it falls back to `pod install --deployment` only if needed.
- GitHub Actions no longer spends time installing CocoaPods on the normal coherent-vendored-Pods path.
- Added verification rule 34 for deterministic Pods lock coherence, required xcconfigs, inherited linker/search/Swift flags, and core iOS 26/iPhone-only build settings.
- Core PiP/0.1pt/VideoCall/high-refresh/PlayerLayer behavior unchanged.

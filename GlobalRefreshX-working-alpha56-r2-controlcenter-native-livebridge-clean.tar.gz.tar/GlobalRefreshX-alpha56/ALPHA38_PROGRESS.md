# GlobalRefresh X — Alpha 38

Focus: maximize the chance that the first GitHub Actions build actually uses an iOS 26-capable Xcode instead of the macOS 15 runner's older default Xcode.

Changes:
- GitHub Actions runner moved from `macos-15` to `macos-26`.
- Added `scripts/select_xcode_26.sh` to select an installed Xcode whose iPhoneOS SDK is 26+ and export `DEVELOPER_DIR` for subsequent CI steps.
- Removed hard-coded `/Applications/Xcode.app/Contents/Developer` selection.
- Added verification rule 29 so CI cannot silently regress to an older default Xcode.
- Runtime PiP / 0.1pt geometry / high-refresh DisplayLink logic unchanged.

Reasoning:
- The current GitHub macOS 15 image still defaults to Xcode 16.4 even though Xcode 26 variants are installed.
- The macOS 26 image defaults to Xcode 26.x and currently carries multiple Xcode 26 releases, reducing first-build risk.

Validation performed in this environment:
- project verification
- Swift parser pass
- plist lint
- shell syntax checks for build and Xcode-selection scripts

A real UIKit/AVKit type-check, link, and unsigned IPA build still requires macOS/Xcode.

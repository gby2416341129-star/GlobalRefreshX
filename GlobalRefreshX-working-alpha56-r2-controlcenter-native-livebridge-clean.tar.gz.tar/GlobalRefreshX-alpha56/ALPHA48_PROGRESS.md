# Alpha48 Progress

- Version: 2.0.0-alpha48-r1; build: 2026090650.
- Added live CADisplayLink scheduling diagnostics to the Frame Rate page (Hz + callback interval).
- Diagnostics are explicitly labeled as this app's callback cadence, not another app's FPS or physical panel Hz.
- Fixed the home PiP status info overlay auto-opening/persisting over controls. It now defaults off and never auto-opens on launch.
- Kept Alpha47-r1 Adaptive Boost core policy: 1...120 Hz, preferred 0, VideoCall route unchanged.

- Alpha48-r1: fixed Live Scheduling Diagnostics state ownership; measuredFPS/measuredIntervalMs now belong to RootFrameRateTestView, resolving Xcode scope errors.

# GlobalRefresh X Alpha 47

## Changes
- Removed the full-screen repeating red TEST/测试用 watermark from the Home screen.
- Kept the beta/test build identification in the About/Version surface instead of obscuring the primary UI.
- Preserved the proven Alpha46 VideoCall + 0.1 pt + 120/120/120 refresh request path unchanged for device A/B validation.
- Preserved the PlayerLayer compatibility route for apps whose own 60 Hz rendering/danmaku cadence may conflict with the VideoCall path.
- Version bumped to 2.0.0-alpha47 (build 2026090647).

## Runtime note
A CADisplayLink frame-rate preference is a best-effort request. The app cannot reliably measure another foreground app's physical panel refresh rate from the background, so Alpha47 does not claim a fake system-wide FPS meter.

## Alpha47-r1 Adaptive Boost revision (2026-09-06)

- Replaced the app-level hard 120/120/120 CADisplayLink request with a public-API adaptive range: minimum 1, maximum device-capped target (up to 120), preferred 0.
- Goal: let iOS/ProMotion fall to the lowest cadence supported by the current device while idle, then ramp toward 120 Hz when foreground interaction/animation requires it.
- Important limitation: a background PiP helper cannot observe touch or scroll events inside another app, so GlobalRefresh X does not itself switch 1 -> 120 on external touches; the system scheduler performs that transition inside the allowed range.
- Preserved VideoCall PiP, 0.1 pt hide, CADisableMinimumFrameDurationOnPhone, PlayerLayer compatibility route, PiP-only keep-alive, and the rest of the Alpha47 core architecture.
- Version: 2.0.0-alpha47-r1; build: 2026090648.

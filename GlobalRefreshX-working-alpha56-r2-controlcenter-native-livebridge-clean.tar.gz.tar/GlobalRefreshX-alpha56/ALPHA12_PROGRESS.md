# GlobalRefresh X Alpha 12

## 本轮重点：把“每次改动必须审查”变成可执行规则

- 新增 `scripts/verify_project.sh`，每次提交/构建前统一执行静态验收。
- 校验 Info.plist 格式、iOS 26+ 部署策略、iPhone-only 策略、armv7 遗留、Swift 全量语法、核心控制器 Xcode 工程引用、合并冲突标记。
- 将版本更新为 `2.0.0-alpha12` / `2026090512`。
- 本轮不改变 120Hz、0.1pt、VideoCall/PlayerLayer 的运行语义，降低回归风险。

## 审查原则

静态检查通过不等于真机行为已证明。最终 Release 仍必须由 GitHub macOS/Xcode CI 完整编译，并在 iPhone 17 Air / iOS 26-27 上做 PiP、120Hz、后台、锁屏、抢占、反复启停等行为验证。

# GlobalRefresh X Alpha56 Progress

- Version: 2.0.0-alpha56 (2026090860)
- Control kind: `com.yoroin.globalrefresh.control.runtime.v4`
- Rebuilt Control Center template with a native leading SF Symbol in the primary `Label`.
- Permanent value text is `运行中` / `未运行`; transient system status uses `controlWidgetStatus`.
- Control intent metadata now exists in both the widget extension and host app target.
- Action flow tries zero-UI Darwin IPC first; if the host is suspended, it requests a dynamic foreground transition and resends the command after SceneDelegate registration.
- Runtime truth remains PiP/refresh-session based; no host response means not running.
- Force-quitting the app still terminates the PiP/CADisplayLink runtime by iOS design; Alpha56 does not fake persistence after force quit.

# GlobalRefresh X — Alpha 41

- Fixed a real Xcode project-graph defect: `HomePresentationState.swift` reused the same PBXFileReference and PBXBuildFile IDs as `DelayedTaskScheduler.swift`.
- Assigned unique PBX object IDs to `HomePresentationState.swift` while preserving source membership and runtime behavior.
- Added verification rule 32 to reject duplicate PBX object identifiers before CI/Xcode build.
- No changes to VideoCall PiP, 0.1pt geometry, refresh-rate driver, PlayerLayer compatibility route, or keep-alive policy.
- Version: 2.0.0-alpha41 (2026090641).

# Alpha49 Progress

- Version: 2.0.0-alpha49; build: 2026090651.
- Reverted adaptive 1-120 policy after real-device feedback showed apps falling to 60/80 Hz.
- Core request is again a strict maximum-refresh request: min=max=preferred=the supported target (120 Hz on a 120 Hz device).
- The single core CADisplayLink callback remains intentionally empty to minimize main-run-loop work.
- Follow-switch and live diagnostics now match the hard high-refresh policy while high refresh is enabled.
- Did not add UIUpdateLink low-latency flags: Apple documents low-latency event dispatch as Pencil-only, and immediate presentation affects this app's own rendering rather than other foreground apps and can cause dropped frames if misused.

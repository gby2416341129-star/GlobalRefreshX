# Alpha 4 progress

This snapshot merges the build pipeline from alpha1 with the core refactors from alpha2/alpha3 and adopts the new platform policy.

Changes:
- iOS deployment target raised from 15.0 to 26.0.
- iPhone-only target policy; legacy iPad compatibility removed from Info.plist.
- Removed obsolete armv7 device capability requirement.
- App metadata updated to GlobalRefresh X 2.0.0-alpha4.
- Removed impossible pre-iOS-26 runtime branches for clock-mode availability and legacy PiP compatibility.
- Retained VideoCall and PlayerLayer PiP routes; no behavior-changing refresh-rate rewrite was made without device validation.
- Merged unsigned IPA build script and GitHub Actions workflow into the canonical development tree.

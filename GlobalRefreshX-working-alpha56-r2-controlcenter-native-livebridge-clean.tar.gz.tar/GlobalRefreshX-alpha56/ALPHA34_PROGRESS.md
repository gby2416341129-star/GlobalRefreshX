# Alpha 34

- Added generation guards to the two remaining multi-delay PiP retry batches in `ViewController`.
- A newly scheduled retry batch now invalidates callbacks belonging to an older batch.
- This prevents stale direct-close gesture installation and stale PlayerLayer custom-view attachment work from running after a newer PiP state has superseded it.
- Core VideoCall/0.1pt/high-refresh scheduling is unchanged.
- Verification expanded to 25 checks.
- Version: 2.0.0-alpha34 (2026090534).

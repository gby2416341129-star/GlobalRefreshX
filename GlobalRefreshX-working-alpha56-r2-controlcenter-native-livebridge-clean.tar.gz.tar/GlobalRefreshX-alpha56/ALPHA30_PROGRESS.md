# GlobalRefresh X — Alpha 30

Version: 2.0.0-alpha30 (2026090530)

## Changes
- Found and removed two stale `MainTabBarController.deinit` references (`pendingShortcutRetryWorkItems`, `refreshDisplayLink`) whose owners had already been removed by earlier refactors. Swift parser cannot detect unresolved symbols, so these were a potential real Xcode compile blocker.
- Migrated the remaining delayed changelog/reset-celebration UI callbacks in `MainTabBarController` from raw `DispatchQueue.main.asyncAfter` to the existing single-owner `DelayedTaskScheduler`.
- Added dedicated `.latestChangelog` and `.resetCelebration` scheduler slots; `deinit` cancellation now covers these jobs automatically.
- Expanded verification from 20 to 22 checks to reject stale removed tab-controller symbols and unmanaged delayed main-queue work in `MainTabBarController`.
- High-refresh PiP mechanisms were intentionally unchanged.

## Verification
- 22/22 project verification passed.
- Swift frontend parse passed for all Swift sources.
- Info.plist lint passed.

## Important limitation
Local Swift parsing is syntax-only on this non-Xcode environment. Alpha 30 removes a concrete likely type-check/compile blocker, but a macOS/Xcode Release build is still required before claiming a buildable IPA.

# GlobalRefresh X Alpha 44

- Added an Xcode workspace/scheme preflight before the real unsigned device build.
- CI now runs `xcodebuild -list` and `xcodebuild -showBuildSettings` with the exact Release/iPhoneOS/signing-disabled context before compilation.
- This catches missing/shared scheme, broken workspace, configuration resolution, deployment target, device family, SDK, Swift version, and bundle-ID resolution earlier in the first macOS/Xcode build.
- Added verification rule 35 to prevent losing this preflight.
- Core PiP/0.1pt/VideoCall/high-refresh/PlayerLayer behavior unchanged.
- Version: 2.0.0-alpha44 (2026090644).

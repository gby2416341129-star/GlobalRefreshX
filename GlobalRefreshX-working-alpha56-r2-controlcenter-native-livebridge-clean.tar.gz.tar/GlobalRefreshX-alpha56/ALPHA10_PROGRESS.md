# GlobalRefresh X — Alpha 10 进度

版本：`2.0.0-alpha10`  
Build：`2026090510`

## 本轮完成

- 扩展 `PiPTaskScheduler`，统一管理快捷指令启动重试、快捷指令停止重试、PlayerLayer 尺寸重载、PlayerLayer 临时音频释放。
- 删除 `ViewController` 中 4 个独立 `DispatchWorkItem?` 所有权变量，降低旧任务残留和跨轮状态污染风险。
- teardown / watchdog / PiP stop / deinit 继续通过统一 scheduler 取消任务。
- 修正实际 `Info.plist` 版本号此前仍停留在 alpha7 的遗漏；现在版本元数据与开发快照一致。
- Swift 语法解析通过；Info.plist 校验通过。

## 设计原则

延迟任务必须有唯一 owner、唯一 slot、明确取消路径。核心 120Hz、VideoCall、PlayerLayer、0.1pt Geometry 行为本轮不改。

## 下一步

继续审计未纳入统一所有权的异步任务，并开始把 start/stop orchestration 从 `ViewController` 向 PiP Engine / Coordinator 收拢。

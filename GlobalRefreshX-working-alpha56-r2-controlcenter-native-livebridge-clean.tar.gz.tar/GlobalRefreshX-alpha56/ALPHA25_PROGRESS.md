# GlobalRefresh X — Alpha 25

## Focus
Release-normal 120 Hz hot-path audit: disabled diagnostics must be effectively free.

## Changes
- Converted `AppDebugLogger.log` and `logCritical` messages to lazy `@autoclosure` evaluation.
- Added an early diagnostics master-gate before message interpolation is evaluated.
- This prevents string interpolation / formatting work in high-frequency PiP callbacks when Debug is disabled.
- Removed the stale `lastFPSProbeTimestamp` field left after the Alpha 24 FPS-probe cleanup.
- Added verification rule 14 to prevent eager debug-log message construction from returning.

## Core behavior intentionally unchanged
- VideoCall PiP route
- PlayerLayer compatibility route
- 0.1 pt hiding
- RefreshRateController / strict frame-rate request
- PiP lifecycle timing

## Version
- 2.0.0-alpha25
- build 2026090525

## Validation boundary
Static project verification and Swift parser checks are not a substitute for Xcode Release type-check/build or iPhone 17 Air frame-pacing tests.

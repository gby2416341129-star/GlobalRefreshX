# GlobalRefresh X — Alpha 17

## Focus
State-semantics and motion/accessibility audit of the redesigned home hero.

## Changes
- Fixed a real semantic bug: PlayerLayer intentionally stops the app-level refresh CADisplayLink, so `refreshRequestActive` must not dim a genuinely active compatibility-route hero. Added `statusEmphasisActive`, derived from lifecycle activity instead.
- Removed hard-coded `120Hz` from running titles. The title now follows `requestedFrameRate`, preventing UI lies when an experiment/profile requests another rate.
- The numeric Hz content transition now respects Reduce Motion.
- Improved VoiceOver value for the visually-hidden PiP state.
- No new DisplayLink, timer, observer, blur loop, or background task was introduced.

## Review rule
Presentation state remains read-only. PiP lifecycle and refresh scheduling remain owned by their core controllers.

# Alpha 14 进度

- 新增 `HomePresentationState`：首页只消费不可变状态快照，不再让新 UI 成为第二套 PiP 状态源。
- 状态模型覆盖待启用、启动中、运行中、0.1pt 隐藏、关闭中、失败，以及标准/兼容模式。
- 启动庆祝层剩余的普通 `UIView.animate` 改为统一 `AppMotion` 的可中断 `UIViewPropertyAnimator`。
- UI 动画继续与 120Hz 请求完全解耦；没有新增 DisplayLink。
- 版本更新到 2.0.0-alpha14 / 2026090514。
- 本轮继续执行项目验证脚本与 Swift 语法审查。

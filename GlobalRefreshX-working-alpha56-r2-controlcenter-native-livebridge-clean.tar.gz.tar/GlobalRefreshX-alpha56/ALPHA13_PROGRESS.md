# GlobalRefresh X — Alpha 13

## 本轮目标
建立统一的视觉与动画基础层，让后续中文 Liquid Glass UI 不再由每个页面自行决定圆角、间距、字体与动画；同时优先保证 120Hz 下的合成效率和动画可中断性。

## 已完成
- 新增 `AppDesignSystem.swift`：统一间距、圆角、字号、动态字体与最小触控尺寸。
- 新增 `AppMotion.swift`：统一动画时长、入场 transform/alpha、Reduce Motion 处理。
- 重写 Tab 内容切换动画为 `UIViewPropertyAnimator`，支持 interruptible animator，不再使用一次性 `UIView.animate`。
- 动画限定在 `opacity + transform` 为主，避免为了视觉效果做高成本布局动画；这与 120Hz 显示下保持稳定合成帧时间的目标一致。
- UI 动画层与刷新率请求层继续彻底分离；UI 动画不会自行创建额外 `CADisplayLink`。
- `verify_project.sh` 已纳入新设计/动画核心文件的工程引用检查。
- 版本更新至 `2.0.0-alpha13` / `2026090513`。

## 审核原则
1. 视觉必须统一，不允许页面自行发明 magic number。
2. 动画必须可中断、可取消，并尊重 Reduce Motion。
3. 默认优先 transform/opacity，避免不必要的 Auto Layout 连续动画和离屏渲染。
4. 不把“120Hz 强制机制”与 UI 动画帧驱动耦合。
5. 后续首页 UI 必须用真实状态模型驱动，不能以动画假装状态已经改变。

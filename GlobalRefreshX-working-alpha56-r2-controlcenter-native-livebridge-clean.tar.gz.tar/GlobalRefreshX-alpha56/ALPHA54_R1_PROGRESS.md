# Alpha54-r1 — Clean Build Identity

- Version: `2.0.0-alpha54-r1`
- Build: `2026090758`
- Host and Control Extension now both derive `CFBundleShortVersionString` / `CFBundleVersion` from Xcode build settings.
- Host and extension build settings use the exact same version/build.
- Control kind remains `com.yoroin.globalrefresh.control.runtime.v2` to avoid reuse of the original cached control.
- CI now hard-fails if the packaged IPA contains mismatched host/extension version metadata or the expected Control kind is absent from the extension binary.

# GlobalRefresh X – Alpha 5 progress

## PiP geometry extraction

Alpha 5 starts the second-stage core refactor by moving PiP sizing policy out of the large `ViewController.swift`.

- Added `PiPGeometryController.swift` as the single owner for PiP height limits, step sizes, hidden-state rules, and centered source geometry.
- VideoCall remains the primary route with a 0.1 pt minimum and 0.1 pt adjustment precision.
- PlayerLayer remains the compatibility route with a 1 pt minimum and 1 pt precision.
- PiP geometry is now route-aware through a typed `Route` enum instead of repeated conditionals and magic numbers.
- `ViewController` now queries geometry metrics from one controller instead of duplicating 0.1/1/22/44/220 sizing rules.
- Centered source-layer frame calculation is centralized, reducing future iPhone 17 Air safe-area/layout drift risk.
- No refresh-rate mechanism was changed in this refactor.

## Next

1. Extract PiP engine creation/teardown (VideoCall vs PlayerLayer) from `ViewController`.
2. Collapse duplicate transition booleans into the lifecycle controller.
3. Add deterministic recovery paths for interruption / suspension / stale transitions.
4. Begin the iOS 26/27 native UI layer after engine boundaries are stable.

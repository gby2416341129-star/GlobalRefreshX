# GlobalRefresh X — Alpha 39

## 本轮目标
把“第一次真实 Xcode 构建失败后无法快速定位”的风险降下来，不改动 PiP/高刷核心行为。

## 完成
- `build_unsigned_ipa.sh` 现在把完整 `xcodebuild` 输出保存到 `build/diagnostics/xcodebuild.log`。
- Xcode 构建增加 `-resultBundlePath build/diagnostics/GlobalRefreshX.xcresult`，保留结构化构建诊断。
- 通过 `PIPESTATUS` 保留 `tee` 管道中的真实 `xcodebuild` 退出码，失败不会被日志管道误判为成功。
- GitHub Actions 新增 `Upload Xcode diagnostics`，使用 `if: always()`，即使 Build unsigned IPA 失败也上传日志和 `.xcresult`。
- 诊断 artifact 保留 14 天，便于第一次 macOS/Xcode 真编译后直接定位 Swift/API/链接/资源问题。
- 验证器新增第 30 项，防止诊断链路被后续修改意外移除。
- 版本更新为 `2.0.0-alpha39`，Build `2026090639`。

## 未改动
- VideoCall PiP 主路线。
- 0.1pt PiP 隐藏策略。
- `CADisplayLink.preferredFrameRateRange` 高刷请求。
- PlayerLayer 兼容路线及 30Hz 活动驱动。

## 当前结论
本轮不是“纸面功能增加”，而是为第一次真实 Xcode 26 构建准备可追踪的失败证据。静态验证通过不等于真实 Xcode 类型检查/链接通过；真正 IPA 仍需要 macOS + Xcode/iPhoneOS SDK。

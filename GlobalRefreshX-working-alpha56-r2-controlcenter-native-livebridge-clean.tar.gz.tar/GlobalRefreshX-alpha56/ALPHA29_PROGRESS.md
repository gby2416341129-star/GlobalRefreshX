# GlobalRefresh X — Alpha 29

## Build-chain audit

- Corrected CocoaPods platform from iOS 15.0 to iOS 26.0 so dependency deployment policy matches the app target.
- `build_unsigned_ipa.sh` now runs `verify_project.sh` itself before CocoaPods/Xcode build, preventing manual/CI callers from bypassing the audit gate.
- IPA packaging now resolves the expected Release app bundle deterministically (`pip_swift.app`) instead of accepting the first arbitrary `.app` found in DerivedData.
- Verification suite expanded from 18 to 20 checks, including Podfile deployment-target consistency and mandatory build-time verification.
- Version bumped to 2.0.0-alpha29 / 2026090529.

## Validation

- 20/20 project verification passed locally.
- Full Swift frontend syntax parse passed as part of verification.
- Info.plist lint passed.
- A true UIKit/AVKit typecheck and Release IPA still require macOS/Xcode.
- GitHub repository write is still blocked by the connected integration returning HTTP 403 on write; no claim of a cloud build is made.

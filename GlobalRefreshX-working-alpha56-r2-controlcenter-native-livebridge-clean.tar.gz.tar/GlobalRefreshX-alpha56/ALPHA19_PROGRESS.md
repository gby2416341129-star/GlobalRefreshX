# GlobalRefresh X — Alpha 19

## 本轮重点：PiP 异步任务所有权审计

本轮对 `ViewController` 的 PiP 启停、快捷指令重试、PlayerLayer 音频收尾、尺寸预览重载等延迟任务进行了集中审计。

### 已完成
- 移除 `ViewController` 内 8 处“先创建局部 `DispatchWorkItem`，再交给 `PiPTaskScheduler` 执行”的双层包装。
- 所有相关延迟操作现在直接由 `PiPTaskScheduler` 持有与取消，减少重复任务对象和取消语义分叉。
- 保持每个任务槽位单实例语义：同类任务再次调度时先取消旧任务，避免快速连续操作产生陈旧回调。
- 未改变 PiP 启动重试次数、延迟、PlayerLayer 启动逻辑、0.1pt 行为或 120Hz 请求策略。
- 将架构约束写入 `verify_project.sh`：
  - 禁止重新引入普通 `UIView.animate`，要求统一走 `AppMotion` / `UIViewPropertyAnimator`。
  - 禁止 `ViewController` 重新直接持有 `DispatchWorkItem`，要求统一走 `PiPTaskScheduler`。

## 为什么这样改
PiP 生命周期最容易出现的问题不是单次调用失败，而是快速连续操作后“旧的延迟任务晚到一步”并覆盖新状态。统一任务所有权后，每个任务槽的取消和替换只有一个入口，可降低 stale callback、重复 start/stop 和状态回滚风险。

## 验证边界
本地验证包括 Swift parser、plist、工程引用、架构 guardrail。UIKit/AVKit 类型检查、真实 Xcode Release 编译与 iPhone 17 Air 真机时序仍必须通过 GitHub Actions/macOS 和实机验证确认。

版本：2.0.0-alpha19 (2026090519)

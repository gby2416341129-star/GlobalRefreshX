# GlobalRefresh X — Alpha 37

## Focus
Xcode project membership integrity before the first real iOS 26 SDK build.

## Changes
- Added a full Swift source membership audit between `pip_swift/pip_swift` and the primary Xcode project.
- The verifier now fails if a Swift source exists on disk but is not referenced by the Xcode project.
- The verifier also fails if the Xcode project references a Swift source that no longer exists on disk.
- This specifically targets parser-invisible/project-file failures that can otherwise appear only during Xcode compilation.
- No changes to the VideoCall PiP, 0.1 pt geometry, core high-refresh DisplayLink, or PlayerLayer cadence.

## Validation
- 28/28 project verification checks.
- Swift syntax parsing.
- Info.plist lint.

## Remaining hard gate
A real Xcode/iPhoneOS 26+ SDK build is still required before claiming an installable IPA.

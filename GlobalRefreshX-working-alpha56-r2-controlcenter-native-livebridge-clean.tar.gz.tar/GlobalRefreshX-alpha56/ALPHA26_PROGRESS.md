# GlobalRefresh X — Alpha 26

Version: 2.0.0-alpha26 (2026090526)

## Focus
Global 120 Hz runtime cleanliness and iOS 26-only code-path audit.

## Changes
- Stopped the 1 Hz PiP runtime-duration UI timer immediately when the app enters background.
- Added an active-app guard so the UI-only runtime ticker cannot be created in background.
- Runtime duration remains exact because it is derived from `pipRuntimeStartedAt` when foreground UI refreshes; no global-refresh behavior depends on the ticker.
- Removed the final unreachable pre-iOS-26 appearance compatibility branch and its legacy hosting-controller rebuild helper.
- Expanded project verification from 14 to 16 checks to prevent both regressions.

## Intentionally unchanged
- VideoCall PiP route and 0.1 pt behavior.
- PlayerLayer compatibility route and activity driver.
- RefreshRateController / strict frame-rate preference behavior.
- PiP start/stop timing and keep-alive policy.

## Validation boundary
Static syntax/project verification is not a substitute for Xcode Release type-checking or iPhone 17 Air frame-pacing validation.

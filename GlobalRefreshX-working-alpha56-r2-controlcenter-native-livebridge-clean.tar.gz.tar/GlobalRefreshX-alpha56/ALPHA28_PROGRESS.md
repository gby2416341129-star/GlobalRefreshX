# GlobalRefresh X — Alpha 28

- Audited remaining CADisplayLink ownership and global-high-refresh hot paths.
- Kept the PlayerLayer 30 Hz activity driver unchanged pending device A/B validation; it may be behaviorally significant.
- Removed a duplicate `measuredPiPFPS = 0` reset discovered during manual code review.
- Added regression verification for that duplicate state-reset pattern.
- Attempted to initialize the connected GitHub repository for the first real Xcode/IPA build. Repository metadata is accessible, but the GitHub integration returned HTTP 403 for the write operation; no source was falsely reported as published.
- Version: 2.0.0-alpha28 (2026090528).

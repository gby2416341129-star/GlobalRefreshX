# GlobalRefresh X — Alpha 23

## 120 Hz interaction audit

- Removed the state-driven SwiftUI blur interpolation from the home settings popover.
- The settings transition now stays on opacity + transform, avoiding repeated offscreen blur filtering during a user-visible transition.
- Added a CI guard that rejects state-driven `.blur(radius: condition ? ...)` on the primary PiPViews surface.
- Preserved Reduce Motion behavior and existing PiP/refresh-rate logic.
- No new CADisplayLink, Timer, observer, background task, or refresh-rate owner was added.

## Validation

- Project verification expanded to 12 checks.
- Full Swift syntax parse performed where swiftc is available.
- Info.plist linted.

## Version

- 2.0.0-alpha23
- Build 2026090523

## Important

Static checks reduce regressions but cannot prove zero dropped frames. Final 120 Hz quality requires Xcode Release builds and on-device frame-time validation on iPhone 17 Air.

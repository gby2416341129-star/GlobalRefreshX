# GlobalRefresh X Alpha 45

- Fixed a real CI/Xcode build blocker discovered by the first GitHub Actions run.
- `scripts/build_unsigned_ipa.sh` now declares its own `WORKSPACE` and `SCHEME` instead of relying on undefined environment variables.
- Hardened CocoaPods fallback: vendored Pods are used when lockfiles match; if they do not match and no Podfile exists, the build fails explicitly instead of invoking `pod install` in an invalid directory.
- Added verifier rule 36 for self-contained build-script paths and CocoaPods snapshot checks.
- Core PiP / 0.1pt / VideoCall / refresh-rate behavior unchanged.

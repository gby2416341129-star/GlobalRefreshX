# GlobalRefresh X — Alpha 9 进度

版本：`2.0.0-alpha9`  
Build：`2026090509`

## 本轮重点：PiP 延迟任务统一所有权

新增 `PiPTaskScheduler.swift`，集中管理 PiP 核心状态切换中的三类延迟任务：

- `startRetry`：PiP 启动等待 / 重试
- `startTimeout`：PiP 启动超时
- `transitionWatchdog`：PiP 状态切换看门狗

### 解决的问题

原实现由 `ViewController` 分别持有多个 `DispatchWorkItem?`。不同启动、停止、重试和 delegate 回调路径都需要手工取消并置空，容易出现：

1. 旧重试任务晚到，覆盖新的用户操作；
2. 超时任务在 PiP 已经成功后仍然存活；
3. watchdog 与新一轮 transition 重叠；
4. 某条异常分支漏掉取消，形成“幽灵任务”。

新的 scheduler 对每一种任务只保留一个 slot。重新 schedule 同 slot 会先取消旧任务；任务执行后自动从 registry 移除；`cancelAll()` 可用于销毁、失败恢复和系统强制停止等关键边界。

### 本轮未修改

- 120Hz 请求机制
- VideoCall / PlayerLayer 两条 PiP 路线的核心行为
- 0.1pt Geometry 规则
- PlayerLayer 音频兼容策略

目的仍然是控制单轮改动范围，避免稳定性重构影响已有高刷效果。

## 校验

- `Info.plist`：通过 `plutil -lint`
- `ViewController.swift`：Swift frontend parse 通过
- `PiPTaskScheduler.swift`：Swift frontend parse 通过
- 新文件已加入 Xcode project 的 Sources Build Phase

## 下一步

继续把 shortcut start/stop retry、PlayerLayer reload/audio-release 这几类延迟任务逐步纳入统一任务所有权；随后拆分 PiP start/stop orchestration，进一步减少 `ViewController` 的职责。

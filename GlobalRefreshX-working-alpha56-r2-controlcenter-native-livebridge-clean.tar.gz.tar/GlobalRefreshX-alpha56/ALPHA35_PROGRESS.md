# Alpha 35 Progress

- Added a generation guard to the foreground-resign retry batch used after PiP close.
- Re-entering the close/restore path now invalidates callbacks from an older retry batch, preventing stale compatibility actions from racing a newer PiP lifecycle state.
- Kept the VideoCall 0.1pt PiP and global refresh CADisplayLink path unchanged.
- Version: 2.0.0-alpha35 (2026090535).

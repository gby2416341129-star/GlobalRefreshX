# GlobalRefresh X — Alpha 6 progress

Alpha 6 starts the PiP engine separation required for the iOS 26/27-only architecture.

## Completed

- Added `PiPEngineController.swift` as the single constructor/owner for route-specific `AVPictureInPictureController` sessions.
- VideoCall construction now uses the modern `AVPictureInPictureController.ContentSource(activeVideoCallSourceView:contentViewController:)` path with no legacy OS fallback.
- PlayerLayer construction is explicit and fails early when its backing layer is not prepared.
- Route-specific `AVPictureInPictureVideoCallViewController` creation moved out of the 6k-line `ViewController`.
- PiP engine teardown now clears the delegate and resets the retained engine session.
- Removed obsolete `#available(iOS 14...)` and `#available(iOS 16...)` branches that cannot execute with the iOS 26 deployment target.
- Added the new engine source file to the Xcode target Sources build phase.

## Intentionally unchanged

- Refresh-rate request behavior.
- VideoCall vs PlayerLayer user-facing route behavior.
- 0.1 pt geometry semantics.
- PlayerLayer backing-video/audio compatibility logic.

## Next

1. Move start/stop/retry transaction handling behind the PiP engine boundary.
2. Replace scattered transition booleans with `PiPLifecycleController` state where safe.
3. Isolate the undocumented `controlsStyle` KVC compatibility hook behind one compatibility adapter.
4. Run the first macOS GitHub Actions compile and fix build-time API issues before UI redesign begins.

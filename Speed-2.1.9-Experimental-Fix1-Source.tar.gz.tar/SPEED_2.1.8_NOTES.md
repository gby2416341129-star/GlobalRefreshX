# Speed 2.1.8 — Aggressive Production Build

Version: 2.1.8  
Build: 2026090881  
Target: iOS 26+ / iOS 27  
Profile: maximum smoothness, minimum self-overhead, production-only (no A/B experiment branch)

## Core refresh policy

- Retains the Alpha49-style single persistent hard-max `CADisplayLink` on `.common`.
- The persistent callback is intentionally empty.
- `minimum`, `maximum`, and `preferred` are pinned to the supported target maximum (up to 120 Hz).
- Runtime refresh routing is driven by the live PiP route, not `UserDefaults`.
- Release `ViewController` has no persistent scrolling/clock display-link or Timer creation path.
- The only other non-debug `CADisplayLink` is the short-lived PiP-height transition link; it is invalidated when the transition completes/cancels.

## PiP lifecycle and auto-hide

- PiP intent, AVKit-confirmed activity, side suspension, and transition ownership are centralized in `PiPLifecycleController`.
- Duplicate AVKit delegate transitions no longer restart the same transition/watchdog.
- Unexpected-stop classification captures pre-stop intent before lifecycle state is reset.
- “Start and hide” no longer relies on a fixed ~0.45 s delay.
- Minimum-height hiding is committed only after AVKit reports the PiP as side-suspended/docked.
- Manual minimum-height action also requires a real docked/suspended PiP state.
- No code path sets `UIApplication.shared.isIdleTimerDisabled = true`.

## Geometry and animation

- PiP height animation progress uses `CADisplayLink.targetTimestamp`.
- PiP content/source geometry submissions are deduplicated at physical-pixel granularity.
- Duplicate `preferredContentSize` / constraint updates are coalesced.
- Explicit `CATransaction.flush()` calls are removed.

## Background execution

- Generic UIKit background task is scoped only to the PiP start transition (`PiPStartTransition`).
- Stable PiP execution does not retain a generic `beginBackgroundTask` assertion.
- Expiration always ends the task.

## Standard VideoCall route

- Production policy is forcibly PiP-only; old installations cannot silently restore continuous or lock-screen silent-audio keep-alive modes.
- Standard VideoCall PiP performs no backing-player work and no recurring AVAudioSession churn.
- Lock-screen-audio / keep-alive-mode notification observers are not registered in the standard production runtime.
- Legacy scrolling and clock content drivers cannot be resurrected by old preferences.

## PlayerLayer compatibility route

- Removes the 30 Hz main-thread PlayerLayer health polling display link.
- Pipeline recovery is event-driven via `AVPlayer.timeControlStatus` and `AVPlayerItemPlaybackStalled`.
- Keeps the known-compatible 30 fps H.264 cadence, but the canonical placeholder is a tiny blank 240×18 surface rather than screen-scale video.
- Player item is no longer regenerated/replaced on every PiP geometry change.
- Compatibility media generation runs on a utility queue and is prewarmed only after the user actually selects PlayerLayer; normal VideoCall launches do zero placeholder-video encoding.
- Transient startup audio needed by PlayerLayer remains route-local and is released after PiP settles.

## SwiftUI / Liquid Glass

- `UIHostingController` root view is created once.
- `SpeedHomeViewModel` coalesces state changes into one `objectWillChange` notification so SwiftUI performs a minimal diff instead of replacing the entire root view.
- Existing grouped `GlassEffectContainer` structure is retained.

## Source pruning

- Removed `PiPTransitionCoordinator.swift` after lifecycle state was consolidated.
- Removed `ReferenceStyleTimeVideoComposition.swift` and reference/experimental PiP engine routes from production source.
- Removed unreferenced icon-work/source-design assets from the distributable source tree; build assets remain in `Assets.xcassets`.
- Release diagnostics remain DEBUG-only/no-op facades.

## Static validation performed

- `scripts/verify_project.sh`: 44/44 checks passed before packaging.
- All app Swift files parsed successfully in normal and `DEBUG` conditional-compilation modes using the available Swift frontend.
- `project.pbxproj` passed `plutil -lint`.
- Shell build/verification scripts passed `bash -n`.

## Validation limitation

This environment does not provide Apple Xcode/iPhoneOS SDK execution, so a real Xcode 26+ compile and iPhone device validation are still required. The included GitHub Actions workflow performs the actual unsigned iPhone build on `macos-26`.


## Fix1 build 2026090882

- Fixed Xcode 26 Release type-check failures caused by removed diagnostic helpers with remaining call sites.
- Removed `AVPlayer.preventsAutomaticBackgroundingDuringVideoPlayback` because it is unavailable on iOS.
- Replaced deprecated `AVAsset(url:)` uses with `AVURLAsset(url:)`.
- Corrected PiP suspension semantics: `isPictureInPictureSuspended` is no longer treated as an edge-docking signal.
- One-tap start-and-hide now waits for a short stable post-start window and never shrinks while PiP is system-suspended.
- Added a dedicated auto-hide scheduler slot so delayed hide work is cancellable and cannot overlap transitions.
- Preserved the Alpha49-style single persistent hard-max refresh driver and all 2.1.8 low-overhead optimizations.


## Fix2 build 2026090883

- Fixed PlayerLayer compatibility mode height changes and one-tap minimum hiding.
- PlayerLayer geometry now uses cached 30fps low-pixel media with an aspect ratio exactly matching the requested 300pt-wide PiP height.
- Prewarms 22pt normal and 1pt minimum media; custom heights generate on a utility queue and swap atomically after commit.
- PlayerLayer one-tap hide commits directly to 1pt instead of a source-view-only animation AVKit cannot reflect.
- Fixed iOS 27 secondary Liquid Glass ghosting by removing the shared controls GlassEffectContainer and making the two secondary glass surfaces non-interactive while preserving press feedback.


## 2.1.9 Experimental build 2026090901

See `SPEED_2.1.9_EXPERIMENTAL_NOTES.md`. This build intentionally reverses some Fix2 low-overhead choices for maximum smoothness testing.

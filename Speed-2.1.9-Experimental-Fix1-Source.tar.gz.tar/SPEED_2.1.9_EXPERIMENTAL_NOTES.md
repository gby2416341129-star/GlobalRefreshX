# Speed 2.1.9 — Aggressive Experimental

Version: 2.1.9  
Build: 2026090901  
Target: iOS 26+ / iOS 27  
Profile: maximum smoothness experiment, no A/B branch

## Header Liquid Glass fix

- Removed the remaining `GlassEffectContainer` from the two top-right circular actions.
- Each circle now owns exactly one non-interactive Liquid Glass sampling layer.
- Press feedback stays in `SpeedPressButtonStyle`, preventing iOS 27 nested interactive-glass halo/ghost artifacts.

## Standard mode — aggressive reinforcement

- Keeps the Alpha49-style hard-max `CADisplayLink`: min=max=preferred=the supported maximum, `.common`, empty callback.
- Adds `UIUpdateLink(windowScene:)` while Speed's scene is visible.
- `requiresContinuousUpdates = true` and the same hard-max frame-rate range are requested.
- Deliberately leaves `wantsImmediatePresentation` and low-latency input dispatch off; Apple warns immediate presentation can create dropped frames when rendering misses its deadline.
- PlayerLayer mode still releases the Standard hard-max drivers instead of letting two incompatible policies fight.

## Compatibility mode — aggressive 60/60 pipeline

- Restores the Alpha49-style PlayerLayer activity driver removed by 2.1.8, but raises it to a 60 Hz `.common` cadence.
- The 60 Hz callback is intentionally almost empty and only checks playback health twice per second.
- Generated PlayerLayer geometry media is raised from 30 fps to 60 fps while keeping the exact tiny aspect-ratio-matched pixel surfaces (300×h or 600×2h).
- Uses a new cache filename so old 30 fps assets cannot be reused accidentally.
- Local AVPlayer disables conservative stall waiting and uses `playImmediately(atRate: 1.0)` for startup/recovery.
- Existing event-driven `timeControlStatus` / playback-stalled recovery remains primary; the 60 Hz driver is an additional continuity fallback.

## Expected trade-off

This build intentionally spends more compositor/main-run-loop/media activity than Fix2, especially in compatibility mode. The goal is to test the highest practical smoothness ceiling first; power tuning comes after device results.

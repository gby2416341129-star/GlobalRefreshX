# Speed 2.1.9 Experimental Fix1

Build: 2026090902

- Fixes the Xcode 26.6 compile failure caused by calling the `@MainActor` refresh controller from `SceneDelegate.deinit`.
- Removes the redundant deinit stop; `sceneDidDisconnect` remains the lifecycle shutdown point.
- Marks the `ObservableObject` conformance as `@preconcurrency` to silence the Swift 6 isolation warning while keeping the model main-actor isolated.
- Aggressive Standard and Compatibility refresh strategies are otherwise unchanged from 2.1.9 Experimental.

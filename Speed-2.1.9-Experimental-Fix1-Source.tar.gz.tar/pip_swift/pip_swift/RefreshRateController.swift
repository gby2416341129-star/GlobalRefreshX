import UIKit

/// Experimental aggressive refresh policy for iOS 26/27.
///
/// Standard / VideoCall route:
/// - one empty hard-max CADisplayLink on `.common` remains the background/PiP anchor;
/// - a UIUpdateLink on the active window scene additionally requests continuous hard-max
///   UI updates while Speed itself is foreground-visible.
///
/// Compatibility / PlayerLayer route deliberately releases both hard-max requests so the
/// media cadence can arbitrate 60/120 without competing with the Standard route policy.
enum FrameRatePreference {
    static let didChangeNotification = Notification.Name("speed.refreshRatePolicyDidChange")
    static var isHighRefreshEnabled: Bool { true }
    static var targetFrameRate: Int { min(120, AppDisplayContext.maximumFramesPerSecond) }

    static func preferredFrameRateValue(target: Float) -> Float { target }
}

enum RefreshRuntimeMode: Equatable {
    case videoCall
    case playerLayer
}

enum AppDisplayContext {
    static var activeWindowScene: UIWindowScene? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        return scenes.first(where: { $0.activationState == .foregroundActive })
            ?? scenes.first(where: { $0.activationState == .foregroundInactive })
            ?? scenes.first
    }

    static var screen: UIScreen? { activeWindowScene?.screen }
    static var bounds: CGRect { screen?.bounds ?? .zero }
    static var scale: CGFloat { max(screen?.scale ?? 1, 1) }
    static var maximumFramesPerSecond: Int { max(screen?.maximumFramesPerSecond ?? 60, 60) }
}

@MainActor
final class RefreshRateController {
    static let shared = RefreshRateController()

    private var displayLink: CADisplayLink?
    private var updateLink: UIUpdateLink?
    private weak var updateLinkScene: UIWindowScene?
    private var configuredFrameRate: Float = 0
    private(set) var runtimeMode: RefreshRuntimeMode = .videoCall

    private init() {}

    var isRunning: Bool { displayLink != nil }

    func setRuntimeMode(_ mode: RefreshRuntimeMode) {
        guard runtimeMode != mode else {
            reconcile()
            return
        }
        runtimeMode = mode
        reconcile()
    }

    func reconcile() {
        guard FrameRatePreference.isHighRefreshEnabled, runtimeMode == .videoCall else {
            stop()
            return
        }
        startOrUpdateHardMaxDisplayLink()
        startOrUpdateContinuousUIUpdateLink()
    }

    func stop() {
        displayLink?.invalidate()
        displayLink = nil
        configuredFrameRate = 0

        updateLink?.isEnabled = false
        updateLink = nil
        updateLinkScene = nil
    }

    private func startOrUpdateHardMaxDisplayLink() {
        let requested = requestedFrameRate()
        if let displayLink {
            if configuredFrameRate != requested {
                configure(displayLink, requested: requested)
            }
            if displayLink.isPaused { displayLink.isPaused = false }
            return
        }

        let link = CADisplayLink(target: self, selector: #selector(step(_:)))
        configure(link, requested: requested)
        link.add(to: .main, forMode: .common)
        link.isPaused = false
        displayLink = link
    }

    private func startOrUpdateContinuousUIUpdateLink() {
        guard let scene = AppDisplayContext.activeWindowScene else {
            updateLink?.isEnabled = false
            updateLink = nil
            updateLinkScene = nil
            return
        }

        let requested = requestedFrameRate()
        if updateLink == nil || updateLinkScene !== scene {
            updateLink?.isEnabled = false
            let link = UIUpdateLink(windowScene: scene)
            link.requiresContinuousUpdates = true
            link.wantsImmediatePresentation = false
            link.wantsLowLatencyEventDispatch = false
            link.isEnabled = true
            updateLink = link
            updateLinkScene = scene
        }

        updateLink?.preferredFrameRateRange = CAFrameRateRange(
            minimum: requested,
            maximum: requested,
            preferred: requested
        )
        updateLink?.requiresContinuousUpdates = true
        updateLink?.isEnabled = true
    }

    private func requestedFrameRate() -> Float {
        Float(min(FrameRatePreference.targetFrameRate, AppDisplayContext.maximumFramesPerSecond))
    }

    private func configure(_ link: CADisplayLink, requested: Float) {
        link.preferredFrameRateRange = CAFrameRateRange(
            minimum: requested,
            maximum: requested,
            preferred: requested
        )
        configuredFrameRate = requested
    }

    @objc private func step(_ link: CADisplayLink) {
        // Intentionally empty. Any main-thread work here steals from the 8.33 ms budget.
    }
}

import Foundation
import WidgetKit

/// Shared, low-frequency runtime state used only by the iOS Control Center control.
/// This is intentionally kept out of the 120 Hz CADisplayLink hot path.
enum ControlCenterRuntimeState {
    static let appGroupIdentifier = "group.com.yoroin.globalrefresh.shared"
    static let controlKind = "com.yoroin.globalrefresh.control.runtime.v2"

    private static let runningKey = "control.runtime.running.v1"
    private static let heartbeatKey = "control.runtime.heartbeat.v1"
    private static let desiredKey = "control.runtime.desired.v1"
    private static let commandGenerationKey = "control.runtime.commandGeneration.v1"
    private static let heartbeatInterval: TimeInterval = 20

    private static let queue = DispatchQueue(label: "com.yoroin.globalrefresh.control-state", qos: .utility)
    private static var heartbeatTimer: DispatchSourceTimer?

    static var sharedContainerAvailable: Bool {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroupIdentifier) != nil
    }

    static var defaults: UserDefaults? {
        guard sharedContainerAvailable else { return nil }
        return UserDefaults(suiteName: appGroupIdentifier)
    }

    static func markRunning() {
        queue.async {
            guard let defaults else { return }
            defaults.set(true, forKey: runningKey)
            defaults.set(true, forKey: desiredKey)
            defaults.set(ProcessInfo.processInfo.systemUptime, forKey: heartbeatKey)
            startHeartbeatLocked()
            DispatchQueue.main.async { reloadControl() }
        }
    }

    static func markStopped() {
        queue.async {
            heartbeatTimer?.cancel()
            heartbeatTimer = nil
            guard let defaults else { return }
            defaults.set(false, forKey: runningKey)
            defaults.set(false, forKey: desiredKey)
            defaults.set(ProcessInfo.processInfo.systemUptime, forKey: heartbeatKey)
            DispatchQueue.main.async { reloadControl() }
        }
    }

    static func refreshHeartbeatIfRunning() {
        queue.async {
            guard let defaults else { return }
            guard defaults.bool(forKey: runningKey) else { return }
            defaults.set(ProcessInfo.processInfo.systemUptime, forKey: heartbeatKey)
        }
    }

    static func consumeDesiredCommand(after generation: Int) -> (generation: Int, desired: Bool)? {
        guard let defaults else { return nil }
        let current = defaults.integer(forKey: commandGenerationKey)
        guard current > generation else { return nil }
        return (current, defaults.bool(forKey: desiredKey))
    }

    static var commandGeneration: Int {
        defaults?.integer(forKey: commandGenerationKey) ?? 0
    }

    private static func startHeartbeatLocked() {
        heartbeatTimer?.cancel()
        let timer = DispatchSource.makeTimerSource(queue: queue)
        timer.schedule(deadline: .now() + heartbeatInterval, repeating: heartbeatInterval, leeway: .seconds(4))
        timer.setEventHandler {
            guard let defaults else { return }
            guard defaults.bool(forKey: runningKey) else { return }
            defaults.set(ProcessInfo.processInfo.systemUptime, forKey: heartbeatKey)
        }
        heartbeatTimer = timer
        timer.resume()
    }

    @MainActor
    private static func reloadControl() {
        ControlCenter.shared.reloadControls(ofKind: controlKind)
    }
}

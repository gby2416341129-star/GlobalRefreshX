//
//  SceneDelegate.swift
//  pip_swift
//
//  Created by 无夜之星辰 on 2021/5/26.
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?
    private var lastControlCommandGeneration = 0

    private static let controlCommandCallback: CFNotificationCallback = { _, observer, _, _, _ in
        guard let observer else { return }
        let delegate = Unmanaged<SceneDelegate>.fromOpaque(observer).takeUnretainedValue()
        DispatchQueue.main.async {
            delegate.consumeControlCenterCommandIfNeeded()
        }
    }


    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene else { return }

        let window = UIWindow(windowScene: windowScene)
        window.rootViewController = MainTabBarController()
        AppAppearancePreference.apply(to: window)
        self.window = window
        window.makeKeyAndVisible()

        lastControlCommandGeneration = max(0, ControlCenterRuntimeState.commandGeneration - 1)
        CFNotificationCenterAddObserver(
            CFNotificationCenterGetDarwinNotifyCenter(),
            Unmanaged.passUnretained(self).toOpaque(),
            Self.controlCommandCallback,
            "com.yoroin.globalrefresh.control.command" as CFString,
            nil,
            .deliverImmediately
        )

        handleShortcutURLContexts(connectionOptions.urlContexts)
        consumeControlCenterCommandIfNeeded()
    }

    deinit {
        CFNotificationCenterRemoveObserver(
            CFNotificationCenterGetDarwinNotifyCenter(),
            Unmanaged.passUnretained(self).toOpaque(),
            nil,
            nil
        )
    }

    func sceneDidDisconnect(_ scene: UIScene) {
        // Called as the scene is being released by the system.
        // This occurs shortly after the scene enters the background, or when its session is discarded.
        // Release any resources associated with this scene that can be re-created the next time the scene connects.
        // The scene may re-connect later, as its session was not necessarily discarded (see `application:didDiscardSceneSessions` instead).
    }

    func sceneDidBecomeActive(_ scene: UIScene) {
        consumeControlCenterCommandIfNeeded()
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
        print("sceneDidEnterBackground")
    }

    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        handleShortcutURLContexts(URLContexts)
    }

    private func consumeControlCenterCommandIfNeeded() {
        guard let command = ControlCenterRuntimeState.consumeDesiredCommand(after: lastControlCommandGeneration) else { return }
        lastControlCommandGeneration = command.generation
        (window?.rootViewController as? MainTabBarController)?
            .handleSystemControlRequest(desiredRunning: command.desired)
    }

    private func handleShortcutURLContexts(_ URLContexts: Set<UIOpenURLContext>) {
        for context in URLContexts {
            if PiPShortcutActionCenter.request(from: context.url) {
                (window?.rootViewController as? MainTabBarController)?
                    .handleExternalShortcutRequest(reason: "URL快捷指令")
                break
            }
        }
    }

}

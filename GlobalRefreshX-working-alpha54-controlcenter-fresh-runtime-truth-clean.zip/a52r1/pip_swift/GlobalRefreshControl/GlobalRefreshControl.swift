import AppIntents
import Foundation
import SwiftUI
import WidgetKit

private enum SharedControlStore {
    static let appGroupIdentifier = "group.com.yoroin.globalrefresh.shared"
    static let controlKind = "com.yoroin.globalrefresh.control.runtime.v2"

    private static let runningKey = "control.runtime.running.v1"
    private static let heartbeatKey = "control.runtime.heartbeat.v1"
    private static let desiredKey = "control.runtime.desired.v1"
    private static let commandGenerationKey = "control.runtime.commandGeneration.v1"
    private static let staleAfter: TimeInterval = 45

    static var sharedContainerAvailable: Bool {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroupIdentifier) != nil
    }

    static var defaults: UserDefaults? {
        // Fail closed. Never fall back to .standard because host and extension
        // would then read different containers and could display a false state.
        guard sharedContainerAvailable else { return nil }
        return UserDefaults(suiteName: appGroupIdentifier)
    }

    static var isRunning: Bool {
        guard let defaults else { return false }
        guard defaults.bool(forKey: runningKey) else { return false }
        let heartbeat = defaults.double(forKey: heartbeatKey)
        let now = ProcessInfo.processInfo.systemUptime
        guard heartbeat > 0, heartbeat <= now else { return false }
        return now - heartbeat <= staleAfter
    }

    static func request(_ desired: Bool) {
        guard let defaults else { return }
        let nextGeneration = defaults.integer(forKey: commandGenerationKey) &+ 1
        defaults.set(desired, forKey: desiredKey)
        defaults.set(nextGeneration, forKey: commandGenerationKey)
        CFNotificationCenterPostNotification(
            CFNotificationCenterGetDarwinNotifyCenter(),
            CFNotificationName("com.yoroin.globalrefresh.control.command" as CFString),
            nil,
            nil,
            true
        )
    }
}

struct GlobalRefreshRuntimeControl: ControlWidget {
    static let kind = SharedControlStore.controlKind

    var body: some ControlWidgetConfiguration {
        StaticControlConfiguration(kind: Self.kind, provider: Provider()) { isRunning in
            ControlWidgetToggle(
                isOn: isRunning,
                action: SetGlobalRefreshRunningIntent(),
                label: {
                    Label("GlobalRefresh X", systemImage: "bolt.fill")
                        .multilineTextAlignment(.center)
                },
                valueLabel: { running in
                    Label(running ? "运行中" : "未运行", systemImage: running ? "bolt.fill" : "bolt.slash")
                        .multilineTextAlignment(.center)
                        .controlWidgetStatus(running ? "运行中" : "未运行")
                }
            )
        }
        .displayName("GlobalRefresh X")
        .description("只显示 GlobalRefresh X 高刷核心是否真正工作，并可直接开关。")
    }

    struct Provider: ControlValueProvider {
        // Keep the gallery preview visually meaningful; the real control always
        // replaces this with currentValue() before presenting runtime state.
        let previewValue = false

        func currentValue() async throws -> Bool {
            SharedControlStore.isRunning
        }
    }
}

struct SetGlobalRefreshRunningIntent: SetValueIntent {
    static let title: LocalizedStringResource = "GlobalRefresh X"
    static let description = IntentDescription("启动或停止 GlobalRefresh X 高刷核心。")
    static let supportedModes: IntentModes = [.background, .foreground(.dynamic)]

    @Parameter(title: "运行中")
    var value: Bool

    func perform() async throws -> some IntentResult {
        SharedControlStore.request(value)

        // Starting PiP needs a UIKit scene. When the app process/scene is absent,
        // ask iOS to continue in the foreground. If it is already alive, the
        // Darwin command is consumed without needlessly reopening the main UI.
        if value, !SharedControlStore.isRunning, systemContext.currentMode.canContinueInForeground {
            try await continueInForeground(
                IntentDialog("启动 GlobalRefresh X"),
                alwaysConfirm: false
            )
        }

        return .result()
    }
}

@main
struct GlobalRefreshControlBundle: WidgetBundle {
    var body: some Widget {
        GlobalRefreshRuntimeControl()
    }
}
